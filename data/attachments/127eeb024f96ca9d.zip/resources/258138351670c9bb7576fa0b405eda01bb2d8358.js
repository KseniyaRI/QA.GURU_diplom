"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["create-page"],{

/***/ 524303:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClientCardDense: () => (/* binding */ ClientCardDense)
/* harmony export */ });
/* harmony import */ var _Users_kryabukhin001_Documents_aurora_node_modules_babel_runtime_helpers_esm_objectWithoutPropertiesLoose_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(173033);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _features_dictionary_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(272713);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);


const _excluded = ["client", "selected", "rootRef"];
var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/clients/client-card-dense.tsx";





/**
 * Элемент одного клиента
 */
function ClientCardDense(props) {
  const {
      client,
      selected,
      rootRef
    } = props,
    paperProps = (0,_Users_kryabukhin001_Documents_aurora_node_modules_babel_runtime_helpers_esm_objectWithoutPropertiesLoose_js__WEBPACK_IMPORTED_MODULE_3__["default"])(props, _excluded);
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Paper, Object.assign({}, paperProps, {
    square: true,
    elevation: 0,
    ref: rootRef,
    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Stack, {
      spacing: 1,
      width: "100%",
      direction: "row",
      alignItems: "flex-start",
      justifyContent: "space-between",
      children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
        variant: "body1",
        color: selected ? 'primary' : undefined,
        children: (0,_features_dictionary_utils__WEBPACK_IMPORTED_MODULE_2__.getClientNameView)(client)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 17
      }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
        variant: "body2",
        color: "text.disabled",
        children: client.clientCode
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 13
    }, this)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 24,
    columnNumber: 9
  }, this);
}
_c = ClientCardDense;
var _c;
__webpack_require__.$Refresh$.register(_c, "ClientCardDense");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 939513:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BenchmarksAutocomplete: () => (/* binding */ BenchmarksAutocomplete),
/* harmony export */   OTHER_ITEM: () => (/* binding */ OTHER_ITEM)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);





const OTHER_ITEM = {
  id: 'OTHER',
  name: 'Иное'
};
const BenchmarksAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_3__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_2__.useGetBenchmarksQuery, data => {
  const toFormat = data == null ? void 0 : data.data.map(item => ({
    id: item.id,
    name: item.name
  }));
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_2__.getDictionaryFromResponse)({
    data: toFormat ? [...toFormat, OTHER_ITEM] : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 857481:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CLIENT_INPUT_SEARCH_MIN_CHARS: () => (/* binding */ CLIENT_INPUT_SEARCH_MIN_CHARS),
/* harmony export */   ClientsInputAutocomplete: () => (/* binding */ ClientsInputAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const CLIENT_INPUT_SEARCH_MIN_CHARS = 3;
const ClientsInputAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withLazyQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.getClientsByParams, search => ({
  search,
  hasClientCode: true
}), r => {
  var _r$data$items, _r$data;
  return (_r$data$items = r == null || (_r$data = r.data) == null ? void 0 : _r$data.items) != null ? _r$data$items : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 570799:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlBusinessProcessesAutocomplete: () => (/* binding */ ControlBusinessProcessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ControlBusinessProcessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetControlBusinessProcessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 259535:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlBusinessSubprocessesAutocomplete: () => (/* binding */ ControlBusinessSubprocessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ControlBusinessSubprocessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetControlBusinessSubprocessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 82539:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CONTROL_AUTOMATION_LEVEL_OPTIONS: () => (/* binding */ CONTROL_AUTOMATION_LEVEL_OPTIONS),
/* harmony export */   CONTROL_FREQUENCY_OPTIONS: () => (/* binding */ CONTROL_FREQUENCY_OPTIONS),
/* harmony export */   CONTROL_IT_DEPENDENCIES_OPTIONS: () => (/* binding */ CONTROL_IT_DEPENDENCIES_OPTIONS),
/* harmony export */   CONTROL_NATURE_LEVEL_OPTIONS: () => (/* binding */ CONTROL_NATURE_LEVEL_OPTIONS),
/* harmony export */   CONTROL_TYPE_OPTIONS: () => (/* binding */ CONTROL_TYPE_OPTIONS),
/* harmony export */   INFORMATION_TESTING_PURPOSES: () => (/* binding */ INFORMATION_TESTING_PURPOSES)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

const CONTROL_AUTOMATION_LEVEL_OPTIONS = {
  AUTOMATED: 'Автоматизированное',
  IT_DEPENDENT_COMPLETELY_MANUAL: 'Зависимое от ИТ, осуществляемое вручную',
  COMPLETELY_MANUAL: 'Осуществляемое вручную'
};
const CONTROL_NATURE_LEVEL_OPTIONS = {
  DETECTING: 'Обнаруживающее',
  WARNING: 'Предупреждающее'
};
const CONTROL_TYPE_OPTIONS = {
  DIRECT_CONTROLS_AT_ORGANIZATIONAL_LEVEL: 'Прямые средства контроля на уровне организации в целом',
  DIRECT_CONTROLS_AT_OPERATIONAL_LEVEL: 'Прямые средства контроля на уровне операций',
  COMMON_CONTROLS_IN_INFORMATION_SYSTEMS: 'Общие средства контроля в информационных системах'
};
const INFORMATION_TESTING_PURPOSES = {
  C: 'П',
  A: 'Т',
  V: 'Д',
  R: 'ОД'
};
const CONTROL_FREQUENCY_OPTIONS = {
  SEVERAL_TIMES_A_DAY: 'Несколько раз в день',
  DAILY: 'Ежедневно',
  WEEKLY: 'Еженедельно',
  MONTHLY: 'Ежемесячно',
  QUARTERLY: 'Ежеквартально',
  ANNUALLY: 'Ежегодно',
  OTHER: 'Прочее'
};
const CONTROL_IT_DEPENDENCIES_OPTIONS = {
  AUTOMATED_CONTROL: 'Автоматизированное средство контроля',
  AUTOMATED_INTERFACE: 'Автоматизированный интерфейс',
  AUTOMATED_CALCULATION: 'Автоматизированный расчет',
  SECURITY: 'Безопасность',
  IT_INDEPENDENT: 'Зависимость от информационных технологий отсутствует',
  REPORT_GENERATED_BY_ACCOUNTING_PROGRAM: 'Отчет, сформированный бухгалтерской программой'
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 768514:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DepartmentsAutocomplete: () => (/* binding */ DepartmentsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const DepartmentsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetDepartmentsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 860213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EngagementStandardsAutocomplete: () => (/* binding */ EngagementStandardsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const EngagementStandardsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetEngagementStandardsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 206546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EstimateValuesAutocomplete: () => (/* binding */ EstimateValuesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_engagement__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(245303);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const EstimateValuesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_engagement__WEBPACK_IMPORTED_MODULE_1__.useGetEstimateValuesQuery, data => {
  var _data$data$items, _data$data;
  return (_data$data$items = data == null || (_data$data = data.data) == null ? void 0 : _data$data.items) != null ? _data$data$items : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 521123:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fsli1SAutocomplete: () => (/* binding */ Fsli1SAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const Fsli1SAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsli1SQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 996846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fsli2Autocomplete: () => (/* binding */ Fsli2Autocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const Fsli2Autocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsli2SQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 280308:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FsliBusinessProcessesAutocomplete: () => (/* binding */ FsliBusinessProcessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const FsliBusinessProcessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsliBusinessProcessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 59353:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FsliAutocomplete: () => (/* binding */ FsliAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _features_repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(586328);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const FsliAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_repository__WEBPACK_IMPORTED_MODULE_1__.useGetFslIsQuery, data => {
  var _data$data$items;
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse)({
    data: (_data$data$items = data == null ? void 0 : data.data.items) != null ? _data$data$items : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 648105:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BenchmarksAutocomplete: () => (/* reexport safe */ _benchmarks__WEBPACK_IMPORTED_MODULE_18__.BenchmarksAutocomplete),
/* harmony export */   CLIENT_INPUT_SEARCH_MIN_CHARS: () => (/* reexport safe */ _clients__WEBPACK_IMPORTED_MODULE_0__.CLIENT_INPUT_SEARCH_MIN_CHARS),
/* harmony export */   CONTROL_AUTOMATION_LEVEL_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_AUTOMATION_LEVEL_OPTIONS),
/* harmony export */   CONTROL_FREQUENCY_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_FREQUENCY_OPTIONS),
/* harmony export */   CONTROL_IT_DEPENDENCIES_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_IT_DEPENDENCIES_OPTIONS),
/* harmony export */   CONTROL_NATURE_LEVEL_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_NATURE_LEVEL_OPTIONS),
/* harmony export */   CONTROL_TYPE_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_TYPE_OPTIONS),
/* harmony export */   ClientsInputAutocomplete: () => (/* reexport safe */ _clients__WEBPACK_IMPORTED_MODULE_0__.ClientsInputAutocomplete),
/* harmony export */   ControlBusinessProcessesAutocomplete: () => (/* reexport safe */ _control_business_processes__WEBPACK_IMPORTED_MODULE_14__.ControlBusinessProcessesAutocomplete),
/* harmony export */   ControlBusinessSubprocessesAutocomplete: () => (/* reexport safe */ _control_business_subprocesses__WEBPACK_IMPORTED_MODULE_15__.ControlBusinessSubprocessesAutocomplete),
/* harmony export */   DepartmentsAutocomplete: () => (/* reexport safe */ _departments__WEBPACK_IMPORTED_MODULE_1__.DepartmentsAutocomplete),
/* harmony export */   EngagementStandardsAutocomplete: () => (/* reexport safe */ _engagement_standards__WEBPACK_IMPORTED_MODULE_2__.EngagementStandardsAutocomplete),
/* harmony export */   EstimateValuesAutocomplete: () => (/* reexport safe */ _estimate_values__WEBPACK_IMPORTED_MODULE_8__.EstimateValuesAutocomplete),
/* harmony export */   Fsli1SAutocomplete: () => (/* reexport safe */ _fsli_1__WEBPACK_IMPORTED_MODULE_9__.Fsli1SAutocomplete),
/* harmony export */   Fsli2Autocomplete: () => (/* reexport safe */ _fsli_2__WEBPACK_IMPORTED_MODULE_10__.Fsli2Autocomplete),
/* harmony export */   FsliAutocomplete: () => (/* reexport safe */ _fsli__WEBPACK_IMPORTED_MODULE_11__.FsliAutocomplete),
/* harmony export */   FsliBusinessProcessesAutocomplete: () => (/* reexport safe */ _fsli_business_processes__WEBPACK_IMPORTED_MODULE_13__.FsliBusinessProcessesAutocomplete),
/* harmony export */   INFORMATION_TESTING_PURPOSES: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.INFORMATION_TESTING_PURPOSES),
/* harmony export */   IndustriesAutocomplete: () => (/* reexport safe */ _industries__WEBPACK_IMPORTED_MODULE_12__.IndustriesAutocomplete),
/* harmony export */   MaterialityFactorsAutocomplete: () => (/* reexport safe */ _materiality_factors__WEBPACK_IMPORTED_MODULE_19__.MaterialityFactorsAutocomplete),
/* harmony export */   OTHER_ITEM: () => (/* reexport safe */ _benchmarks__WEBPACK_IMPORTED_MODULE_18__.OTHER_ITEM),
/* harmony export */   PrerequisitesAutocomplete: () => (/* reexport safe */ _prerequisite__WEBPACK_IMPORTED_MODULE_3__.PrerequisitesAutocomplete),
/* harmony export */   ReportTypesAutocomplete: () => (/* reexport safe */ _report_types__WEBPACK_IMPORTED_MODULE_4__.ReportTypesAutocomplete),
/* harmony export */   ReportingStandardsAutocomplete: () => (/* reexport safe */ _reporting_standards__WEBPACK_IMPORTED_MODULE_5__.ReportingStandardsAutocomplete),
/* harmony export */   ReportingTypesAutocomplete: () => (/* reexport safe */ _reporting_types__WEBPACK_IMPORTED_MODULE_6__.ReportingTypesAutocomplete),
/* harmony export */   RiskSubprocessesAutocomplete: () => (/* reexport safe */ _risk_subprocesses__WEBPACK_IMPORTED_MODULE_16__.RiskSubprocessesAutocomplete),
/* harmony export */   WorkTypesAutocomplete: () => (/* reexport safe */ _work_types__WEBPACK_IMPORTED_MODULE_7__.WorkTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _clients__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(857481);
/* harmony import */ var _departments__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(768514);
/* harmony import */ var _engagement_standards__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(860213);
/* harmony import */ var _prerequisite__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(863443);
/* harmony import */ var _report_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(858783);
/* harmony import */ var _reporting_standards__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(814672);
/* harmony import */ var _reporting_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(128059);
/* harmony import */ var _work_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(599756);
/* harmony import */ var _estimate_values__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(206546);
/* harmony import */ var _fsli_1__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(521123);
/* harmony import */ var _fsli_2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(996846);
/* harmony import */ var _fsli__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59353);
/* harmony import */ var _industries__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5979);
/* harmony import */ var _fsli_business_processes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(280308);
/* harmony import */ var _control_business_processes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(570799);
/* harmony import */ var _control_business_subprocesses__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(259535);
/* harmony import */ var _risk_subprocesses__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(432092);
/* harmony import */ var _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(82539);
/* harmony import */ var _benchmarks__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(939513);
/* harmony import */ var _materiality_factors__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(517323);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);























const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 5979:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IndustriesAutocomplete: () => (/* binding */ IndustriesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const IndustriesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetIndustriesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 517323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MaterialityFactorsAutocomplete: () => (/* binding */ MaterialityFactorsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const MaterialityFactorsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetMaterialityFactorsQuery, data => {
  var _data$data;
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse)({
    data: (_data$data = data == null ? void 0 : data.data) != null ? _data$data : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 863443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrerequisitesAutocomplete: () => (/* binding */ PrerequisitesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const PrerequisitesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetPrerequisitesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 858783:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportTypesAutocomplete: () => (/* binding */ ReportTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const ReportTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.useGetReportTypesQuery, r => {
  var _r$data;
  return (_r$data = r == null ? void 0 : r.data) != null ? _r$data : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 814672:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportingStandardsAutocomplete: () => (/* binding */ ReportingStandardsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ReportingStandardsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetReportingStandardsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 128059:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportingTypesAutocomplete: () => (/* binding */ ReportingTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const ReportingTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.useGetReportingTypesQuery, r => {
  var _r$data;
  return (_r$data = r == null ? void 0 : r.data) != null ? _r$data : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 432092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RiskSubprocessesAutocomplete: () => (/* binding */ RiskSubprocessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const RiskSubprocessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetRiskSubprocessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 599756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WorkTypesAutocomplete: () => (/* binding */ WorkTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const WorkTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetWorkTypesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 225081:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NAME_FIELD_INFO: () => (/* binding */ NAME_FIELD_INFO)
/* harmony export */ });
/* harmony import */ var _mui_icons_material_EditOutlined__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(234756);
/* harmony import */ var _mui_icons_material_FeaturedPlayListOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(886000);
/* harmony import */ var _mui_icons_material_ListAltOutlined__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(233945);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const NAME_FIELD_INFO = [{
  IconComponent: _mui_icons_material_EditOutlined__WEBPACK_IMPORTED_MODULE_0__["default"],
  title: 'Редактируйте название, чтобы оно соответствовало структуре и наполнению проекта'
}, {
  IconComponent: _mui_icons_material_ListAltOutlined__WEBPACK_IMPORTED_MODULE_1__["default"],
  title: 'Формулируйте название по предложенному шаблону — это поможет легко ориентироваться в списке проектов'
}, {
  IconComponent: _mui_icons_material_FeaturedPlayListOutlined__WEBPACK_IMPORTED_MODULE_2__["default"],
  title: 'Изменяйте название после создания в любой момент в Информации о проекте'
}];

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 360829:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateEngagementForm: () => (/* binding */ CreateEngagementForm)
/* harmony export */ });
/* harmony import */ var _Users_kryabukhin001_Documents_aurora_node_modules_babel_runtime_helpers_esm_objectWithoutPropertiesLoose_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(173033);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(305858);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(855983);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(534237);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(790161);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(116354);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(464901);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var ramda__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(290248);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(80824);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(206315);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _features_dictionary_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(272713);
/* harmony import */ var _features_engagement__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(245303);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(154466);
/* harmony import */ var _app_snackbar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(949136);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(868845);
/* harmony import */ var _clients_client_card_dense__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(524303);
/* harmony import */ var _dictionaries__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(648105);
/* harmony import */ var _safe_navigator__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(523700);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(634984);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(395051);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(225081);
/* harmony import */ var _schema__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(537930);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(913164);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(325712);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(215428);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);


const _excluded = ["client", "department", "workTypes", "reportingStandards"];
let _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/create-page/form.tsx",
  _2 = t => t,
  _t,
  _t2,
  _t3,
  _s = __webpack_require__.$Refresh$.signature();





























const styles = {
  root: () => (0,_mui_material__WEBPACK_IMPORTED_MODULE_22__.css)(_t || (_t = _2`
        grid-template-columns: 460px 516px;
    `)),
  formControl: {
    height: _consts__WEBPACK_IMPORTED_MODULE_17__.FILED_HEIGHT_WITH_ERROR_LABEL
  },
  verificationPeriodsFilled: () => (0,_mui_material__WEBPACK_IMPORTED_MODULE_22__.css)(_t2 || (_t2 = _2`
        input {
            display: contents;
        }
    `)),
  verificationPeriodsFC: () => (0,_mui_material__WEBPACK_IMPORTED_MODULE_22__.css)(_t3 || (_t3 = _2`
        .MuiInputBase-formControl {
            padding-right: 10px !important;
        }
    `))
};
const SAFE_NAVIGATOR_CONFIG = {
  title: 'Проект не создан',
  content: 'Продолжить редактирование?'
};
const CreateEngagementForm = () => {
  _s();
  const currentYear = new Date().getFullYear();
  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    getValues,
    formState: {
      errors
    },
    trigger
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_23__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_24__.yupResolver)(_schema__WEBPACK_IMPORTED_MODULE_20__.schema),
    mode: 'all',
    defaultValues: {
      // @ts-ignore
      client: null,
      workTypes: [],
      reportingStandards: [],
      verificationPeriods: [],
      verificationYear: null,
      // @ts-ignore
      department: null,
      name: `${currentYear}`
    }
  });
  const snackbar = (0,_app_snackbar__WEBPACK_IMPORTED_MODULE_12__.useAppSnackbar)();
  const safeNavigator = (0,_safe_navigator__WEBPACK_IMPORTED_MODULE_16__.useFormSafeNavigator)(control, undefined, SAFE_NAVIGATOR_CONFIG);

  // Блок формирования имени
  const [avatarValue, setAvatarValue] = react__WEBPACK_IMPORTED_MODULE_6___default().useState(getValues('name'));
  const subscriptionValuesArray = watch(['client', 'verificationPeriods', 'verificationYear', 'workTypes', 'reportingStandards']);
  const setNameValue = react__WEBPACK_IMPORTED_MODULE_6___default().useCallback(() => {
    const [client, verificationPeriods, verificationYear, workTypes, reportingStandards] = subscriptionValuesArray;
    const generatedName = (0,_utils__WEBPACK_IMPORTED_MODULE_21__.generateName)({
      client,
      verificationPeriods,
      verificationYear,
      workTypes,
      reportingStandards
    });
    setValue('name', generatedName);
    setAvatarValue(generatedName);
  }, [setValue, subscriptionValuesArray]);
  const [isNameFieldTouched, setIsNameFieldTouched] = react__WEBPACK_IMPORTED_MODULE_6___default().useState(false);
  react__WEBPACK_IMPORTED_MODULE_6___default().useEffect(() => {
    if (!isNameFieldTouched) {
      setNameValue();
    }
  }, [subscriptionValuesArray, isNameFieldTouched, setNameValue]);
  const refreshName = () => {
    setNameValue();
    trigger('name');
  };

  // Блок создания и перехода на страницу с созданным проектом
  const navigate = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_25__.useNavigate)();
  const [createEngagement] = (0,_features_engagement__WEBPACK_IMPORTED_MODULE_10__.useCreateEngagementMutation)();
  const [isSubmitting, setIsSubmitting] = react__WEBPACK_IMPORTED_MODULE_6___default().useState(false);
  const onSubmit = _ref => {
    let {
        client,
        department,
        workTypes,
        reportingStandards
      } = _ref,
      newEngagement = (0,_Users_kryabukhin001_Documents_aurora_node_modules_babel_runtime_helpers_esm_objectWithoutPropertiesLoose_js__WEBPACK_IMPORTED_MODULE_26__["default"])(_ref, _excluded);
    setIsSubmitting(true);
    createEngagement({
      engagementCreateDto: Object.assign({
        clientId: client.id,
        departmentId: department.id,
        typeIds: workTypes == null ? void 0 : workTypes.map(i => i.id),
        reportingStandardIds: reportingStandards == null ? void 0 : reportingStandards.map(i => i.id)
      }, newEngagement)
    }).unwrap().then(result => {
      safeNavigator.unblock();
      snackbar.add({
        message: _consts__WEBPACK_IMPORTED_MODULE_17__.QUERY_MESSAGES.ENGAGEMENT.CREATE.SUCCESS,
        key: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_27__.nanoid)(),
        options: {
          variant: 'success'
        }
      });
      navigate((0,_routes__WEBPACK_IMPORTED_MODULE_11__.getEngagementInfoPage)(String(result.data.id)));
    }).catch(e => {
      snackbar.add({
        message: _consts__WEBPACK_IMPORTED_MODULE_17__.QUERY_MESSAGES.ENGAGEMENT.CREATE.ERROR,
        key: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_27__.nanoid)(),
        options: {
          variant: 'error'
        }
      });
      console.error(e);
    }).finally(() => {
      setIsSubmitting(false);
    });
  };
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)("form", {
    onSubmit: handleSubmit(onSubmit),
    children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Box, {
      display: "grid",
      gap: 20,
      css: styles.root,
      children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Box, {
        display: "grid",
        gap: 6,
        children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Box, {
          children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Typography, {
            variant: "body2",
            children: "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043E \u043F\u0440\u043E\u0435\u043A\u0442\u0435. \u0412\u0432\u0435\u0434\u0435\u043D\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u0443\u044E\u0442 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435. \u041E\u043D\u043E \u043E\u0442\u0440\u0430\u0437\u0438\u0442\u0441\u044F \u0441\u043F\u0440\u0430\u0432\u0430, \u0433\u0434\u0435 \u0435\u0433\u043E \u043C\u043E\u0436\u043D\u043E \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 184,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 183,
          columnNumber: 21
        }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
          container: true,
          columnSpacing: 4,
          columns: 2,
          children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 2,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "client",
              control: control,
              render: ({
                field,
                fieldState
              }) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                fullWidth: true,
                children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_dictionaries__WEBPACK_IMPORTED_MODULE_15__.ClientsInputAutocomplete, {
                  value: field.value,
                  onChange: (_, value) => {
                    field.onChange(value);
                  },
                  minInput: 3,
                  size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                  openOnFocus: false,
                  renderInput: (params, {
                    isError,
                    error
                  }) => {
                    // FIXME: на клиенте ts ignore - он может быть null
                    const maybeClientCodeMissingMessage = field.value ? (0,_utils__WEBPACK_IMPORTED_MODULE_18__.validateClientHasClientCode)(field.value) : null;
                    const getHelperText = () => {
                      var _field$value;
                      if (error != null) {
                        return error;
                      }
                      if (fieldState.error) {
                        var _fieldState$error;
                        return (_fieldState$error = fieldState.error) == null ? void 0 : _fieldState$error.message;
                      }
                      if (maybeClientCodeMissingMessage != null) {
                        return maybeClientCodeMissingMessage;
                      }
                      if ((_field$value = field.value) != null && _field$value.clientCode) {
                        return `Клиентский код: ${field.value.clientCode}`;
                      }
                      return ' ';
                    };
                    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, params, {
                      error: isError || fieldState.invalid || maybeClientCodeMissingMessage != null,
                      name: field.name,
                      onBlur: field.onBlur,
                      ref: field.ref,
                      required: true,
                      label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.client,
                      helperText: getHelperText(),
                      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)('Название клиента', field.value)
                    }), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 227,
                      columnNumber: 53
                    }, undefined);
                  },
                  isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_8__.eqProps('id'),
                  getOptionLabel: _features_dictionary_utils__WEBPACK_IMPORTED_MODULE_9__.getClientNameView,
                  renderOption: (props, option, {
                    selected
                  }) => {
                    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_clients_client_card_dense__WEBPACK_IMPORTED_MODULE_14__.ClientCardDense, Object.assign({
                      client: option,
                      square: true,
                      elevation: 0,
                      selected: selected,
                      component: "li"
                    }, props), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 251,
                      columnNumber: 53
                    }, undefined);
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 196,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 195,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 191,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 190,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 2,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "department",
              control: control,
              render: ({
                field,
                fieldState
              }) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                fullWidth: true,
                children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_dictionaries__WEBPACK_IMPORTED_MODULE_15__.DepartmentsAutocomplete, {
                  queryArgs: {},
                  onChange: (_, value) => {
                    field.onChange(value);
                  },
                  getOptionLabel: o => o.name,
                  openOnFocus: true,
                  size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                  isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_8__.eqProps('id'),
                  disableClearable: true,
                  value: field.value,
                  renderInput: (params, {
                    isError,
                    error
                  }) => {
                    var _fieldState$error$mes, _fieldState$error2;
                    const helperText = error != null ? error : (_fieldState$error$mes = (_fieldState$error2 = fieldState.error) == null ? void 0 : _fieldState$error2.message) != null ? _fieldState$error$mes : ' ';
                    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, params, {
                      error: isError || fieldState.invalid,
                      readOnly: true,
                      name: field.name,
                      onBlur: field.onBlur,
                      ref: field.ref,
                      required: true,
                      label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.department,
                      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)('Отдел общего аудита', field.value),
                      helperText: helperText
                    }), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 289,
                      columnNumber: 53
                    }, undefined);
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 273,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 272,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 268,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 267,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 2,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "workTypes",
              control: control,
              render: ({
                field,
                fieldState
              }) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                fullWidth: true,
                children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_dictionaries__WEBPACK_IMPORTED_MODULE_15__.WorkTypesAutocomplete, {
                  queryArgs: {},
                  limitTags: 3,
                  multiple: true,
                  disableCloseOnSelect: true,
                  getOptionLabel: o => o.name,
                  openOnFocus: false,
                  size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                  isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_8__.eqProps('id'),
                  onChange: (_, value) => {
                    field.onChange(value);
                  },
                  value: field.value,
                  renderTags: (val, getTagsProps, ownerState) => val.map((v, idx) => (0,_emotion_react__WEBPACK_IMPORTED_MODULE_29__.createElement)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Chip, Object.assign({}, getTagsProps({
                    index: idx
                  }), {
                    label: v.nameShort,
                    key: v.id,
                    size: ownerState.size,
                    __self: undefined,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 333,
                      columnNumber: 53
                    }
                  }))),
                  renderInput: (params, {
                    isError,
                    error
                  }) => {
                    var _fieldState$error$mes2, _fieldState$error3;
                    const helperText = error != null ? error : (_fieldState$error$mes2 = (_fieldState$error3 = fieldState.error) == null ? void 0 : _fieldState$error3.message) != null ? _fieldState$error$mes2 : ' ';
                    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, params, {
                      error: isError || fieldState.invalid,
                      readOnly: true,
                      name: field.name,
                      onBlur: field.onBlur,
                      ref: field.ref,
                      label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.types,
                      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)('Аудит', field.value),
                      helperText: helperText
                    }), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 346,
                      columnNumber: 53
                    }, undefined);
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 318,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 317,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 313,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 312,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 2,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "reportingStandards",
              control: control,
              render: ({
                field,
                fieldState
              }) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                fullWidth: true,
                children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_dictionaries__WEBPACK_IMPORTED_MODULE_15__.ReportingStandardsAutocomplete, {
                  queryArgs: {},
                  limitTags: 3,
                  multiple: true,
                  disableCloseOnSelect: true,
                  getOptionLabel: o => o.name,
                  openOnFocus: false,
                  size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                  isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_8__.eqProps('id'),
                  onChange: (_, value) => {
                    field.onChange(value);
                  },
                  value: field.value,
                  renderTags: (val, getTagsProps, ownerState) => val.map((v, idx) => (0,_emotion_react__WEBPACK_IMPORTED_MODULE_29__.createElement)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Chip, Object.assign({}, getTagsProps({
                    index: idx
                  }), {
                    label: v.nameShort,
                    key: v.id,
                    size: ownerState.size,
                    __self: undefined,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 389,
                      columnNumber: 53
                    }
                  }))),
                  renderInput: (params, {
                    isError,
                    error
                  }) => {
                    var _fieldState$error$mes3, _fieldState$error4;
                    const helperText = error != null ? error : (_fieldState$error$mes3 = (_fieldState$error4 = fieldState.error) == null ? void 0 : _fieldState$error4.message) != null ? _fieldState$error$mes3 : ' ';
                    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, params, {
                      error: isError || fieldState.invalid,
                      readOnly: true,
                      name: field.name,
                      onBlur: field.onBlur,
                      ref: field.ref,
                      label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.reportingStandards,
                      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)('МСФО', field.value),
                      helperText: helperText
                    }), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 402,
                      columnNumber: 53
                    }, undefined);
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 374,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 373,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 369,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 368,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 1,
            css: styles.formControl,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "verificationPeriods",
              control: control,
              render: ({
                field
              }) => {
                return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                  fullWidth: true,
                  css: styles.verificationPeriodsFC,
                  children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Autocomplete, Object.assign({}, register('verificationPeriods'), {
                    options: _consts__WEBPACK_IMPORTED_MODULE_17__.VERIFICATION_PERIODS,
                    onChange: (_, value) => field.onChange(value.map(item => item.id)),
                    getOptionLabel: option => option.name,
                    limitTags: 2,
                    renderInput: params => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, params, {
                      readOnly: true,
                      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)('год', field.value),
                      label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.verificationPeriod,
                      size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE
                    }), void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 434,
                      columnNumber: 53
                    }, undefined),
                    size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                    disabled: isSubmitting,
                    css: !getValues('verificationPeriods') && styles.verificationPeriodsFilled,
                    disableCloseOnSelect: true,
                    openOnFocus: true,
                    multiple: true
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 427,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 426,
                  columnNumber: 41
                }, undefined);
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 421,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 420,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Grid, {
            item: true,
            xs: 1,
            css: styles.formControl,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "verificationYear",
              control: control,
              render: ({
                field
              }) => {
                return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                  fullWidth: true,
                  id: "verificationYear",
                  children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, register('verificationYear'), {
                    select: true,
                    label: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.verificationYear,
                    value: field.value,
                    disabled: isSubmitting,
                    size: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_SIZE,
                    placeholder: currentYear.toString(),
                    children: _consts__WEBPACK_IMPORTED_MODULE_17__.VERIFICATION_YEARS.map(year => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.MenuItem, {
                      value: year,
                      children: year
                    }, year, false, {
                      fileName: _jsxFileName,
                      lineNumber: 474,
                      columnNumber: 53
                    }, undefined))
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 464,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 463,
                  columnNumber: 41
                }, undefined);
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 458,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 457,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 189,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 182,
        columnNumber: 17
      }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Box, {
        display: "grid",
        gap: 6,
        children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.Avatar, {
          size: "2x-large",
          value: avatarValue
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 487,
          columnNumber: 21
        }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Stack, {
          children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Box, {
            display: "grid",
            gap: 3,
            children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Stack, {
              direction: "row",
              alignItems: "center",
              justifyContent: "space-between",
              children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Typography, {
                variant: "h6",
                children: _consts__WEBPACK_IMPORTED_MODULE_17__.FIELD_NAMES.name
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 492,
                columnNumber: 33
              }, undefined), isNameFieldTouched && (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.GenerateNameButton, {
                onClick: refreshName,
                disabled: isSubmitting
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 494,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 491,
              columnNumber: 29
            }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(react_hook_form__WEBPACK_IMPORTED_MODULE_23__.Controller, {
              name: "name",
              control: control,
              render: ({
                field
              }) => {
                var _errors$name, _errors$name$message, _errors$name2;
                return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.FormControl, {
                  css: styles.formControl,
                  children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.TextField, Object.assign({}, register('name'), {
                    value: field.value,
                    onChange: ({
                      target: {
                        value
                      }
                    }) => {
                      field.onChange(value);
                      setAvatarValue(value);
                      setIsNameFieldTouched(true);
                      trigger('name');
                    },
                    disabled: isSubmitting,
                    error: !!((_errors$name = errors.name) != null && _errors$name.message),
                    helperText: (_errors$name$message = (_errors$name2 = errors.name) == null ? void 0 : _errors$name2.message) != null ? _errors$name$message : ' ',
                    placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043B\u0438\u0435\u043D\u0442\u0430 / Audit / IFRS / 3 \u043C\u0435\u0441 / 2023",
                    variant: "standard",
                    maxRows: 2,
                    fullWidth: true,
                    multiline: true
                  }), void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 503,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 502,
                  columnNumber: 37
                }, undefined);
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 498,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 490,
            columnNumber: 25
          }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Stack, {
            spacing: 4,
            children: _consts__WEBPACK_IMPORTED_MODULE_19__.NAME_FIELD_INFO.map((Item, idx) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Stack, {
              direction: "row",
              alignItems: "center",
              spacing: 4,
              children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(Item.IconComponent, {
                color: "primary"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 529,
                columnNumber: 37
              }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Typography, {
                variant: "body2",
                color: "secondary",
                children: Item.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 530,
                columnNumber: 37
              }, undefined)]
            }, idx, true, {
              fileName: _jsxFileName,
              lineNumber: 528,
              columnNumber: 33
            }, undefined))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 526,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 489,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 486,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 181,
      columnNumber: 13
    }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.Stack, {
      direction: "row",
      justifyContent: "flex-end",
      mt: 14,
      children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuButton, {
        isSubmitting: isSubmitting,
        disabled: isSubmitting,
        type: "submit",
        variant: "contained",
        size: "large",
        children: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 540,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 539,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 180,
    columnNumber: 9
  }, undefined);
};
_s(CreateEngagementForm, "o5FY29DQagyZKO1cvSA8XjaWNrU=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_23__.useForm, _app_snackbar__WEBPACK_IMPORTED_MODULE_12__.useAppSnackbar, _safe_navigator__WEBPACK_IMPORTED_MODULE_16__.useFormSafeNavigator, react_router_dom__WEBPACK_IMPORTED_MODULE_25__.useNavigate, _features_engagement__WEBPACK_IMPORTED_MODULE_10__.useCreateEngagementMutation];
});
_c = CreateEngagementForm;
var _c;
__webpack_require__.$Refresh$.register(_c, "CreateEngagementForm");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 692439:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CreatePage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _aurora_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(558447);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(215428);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(568688);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(206315);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3259);
/* harmony import */ var _layouts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(351856);
/* harmony import */ var _responses__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(566911);
/* harmony import */ var _form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(360829);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/create-page/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }











const styles = {
  wrapper: theme => /*#__PURE__*/(0,_emotion_react__WEBPACK_IMPORTED_MODULE_6__.css)("display:flex;justify-content:center;align-items:center;margin:", theme.spacing(18), ";" + ( false ? 0 : ";label:wrapper;"),  false ? 0 : "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvY3JlYXRlLXBhZ2UvaW5kZXgudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQWdCa0MiLCJmaWxlIjoiL1VzZXJzL2tyeWFidWtoaW4wMDEvRG9jdW1lbnRzL2F1cm9yYS9wYWNrYWdlcy9mZS1ob3N0LWFwcC9zcmMvYXBwL2NvbXBvbmVudHMvZW5nYWdlbWVudC9jcmVhdGUtcGFnZS9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBBUFBfUk9VVEVTIH0gZnJvbSAnQGF1cm9yYS9jb21tb24nO1xuaW1wb3J0IHR5cGUgeyBUaGVtZSB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IGNzcyB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCBDbG9zZUljb24gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9DbG9zZSc7XG5pbXBvcnQgeyBCb3gsIEljb25CdXR0b24gfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmltcG9ydCB7IFVzZXJQZXJtaXNzaW9uc0d1YXJkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvcGVybWlzc2lvbnMvdXNlci1wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBQYWdlVGl0bGUgfSBmcm9tICcuLi8uLi9sYXlvdXRzJztcbmltcG9ydCB7IFBhZ2VGb3JiaWRkZW4gfSBmcm9tICcuLi8uLi9yZXNwb25zZXMnO1xuXG5pbXBvcnQgeyBDcmVhdGVFbmdhZ2VtZW50Rm9ybSB9IGZyb20gJy4vZm9ybSc7XG5cbmNvbnN0IHN0eWxlcyA9IHtcbiAgICB3cmFwcGVyOiAodGhlbWU6IFRoZW1lKSA9PiBjc3NgXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBtYXJnaW46ICR7dGhlbWUuc3BhY2luZygxOCl9O1xuICAgIGAsXG4gICAgcm9vdDogY3NzYFxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGAsXG4gICAgdGl0bGVSb290OiBjc3NgXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBgLFxufTtcblxuY29uc3QgQ3JlYXRlUGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgY29uc3Qgb25DbG9zZSA9ICgpID0+IG5hdmlnYXRlKEFQUF9ST1VURVMuRU5HQUdFTUVOVC5QQVRIKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxVc2VyUGVybWlzc2lvbnNHdWFyZFxuICAgICAgICAgICAgZGVueUNvbXBvbmVudD17PFBhZ2VGb3JiaWRkZW4gLz59XG4gICAgICAgICAgICBpc0FsbG93ZWQ9eyhidWlsZGVyKSA9PiBidWlsZGVyLkV4YWN0KCdFTkdBR0VNRU5UX0NSRUFURScpfVxuICAgICAgICA+XG4gICAgICAgICAgICA8Qm94IGNzcz17c3R5bGVzLndyYXBwZXJ9PlxuICAgICAgICAgICAgICAgIDxCb3ggZ2FwPXsxNH0gY3NzPXtzdHlsZXMucm9vdH0+XG4gICAgICAgICAgICAgICAgICAgIDxQYWdlVGl0bGUgdGl0bGU9XCLQodC+0LfQtNCw0L3QuNC1INC/0YDQvtC10LrRgtCwXCIgY2xhc3Nlcz17eyByb290OiBzdHlsZXMudGl0bGVSb290IH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gYXJpYS1sYWJlbD1cImNsb3NlXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb3NlSWNvbiBjb2xvcj1cInNlY29uZGFyeVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvUGFnZVRpdGxlPlxuICAgICAgICAgICAgICAgICAgICA8Q3JlYXRlRW5nYWdlbWVudEZvcm0gLz5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L1VzZXJQZXJtaXNzaW9uc0d1YXJkPlxuICAgICk7XG59O1xuXG5leHBvcnQgeyBDcmVhdGVQYWdlIGFzIGRlZmF1bHQgfTtcbiJdfQ== */"),
  root:  false ? 0 : {
    name: "1968mu4-root",
    styles: "display:flex;flex-direction:column;label:root;",
    map: "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvY3JlYXRlLXBhZ2UvaW5kZXgudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXNCYSIsImZpbGUiOiIvVXNlcnMva3J5YWJ1a2hpbjAwMS9Eb2N1bWVudHMvYXVyb3JhL3BhY2thZ2VzL2ZlLWhvc3QtYXBwL3NyYy9hcHAvY29tcG9uZW50cy9lbmdhZ2VtZW50L2NyZWF0ZS1wYWdlL2luZGV4LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB7IEFQUF9ST1VURVMgfSBmcm9tICdAYXVyb3JhL2NvbW1vbic7XG5pbXBvcnQgdHlwZSB7IFRoZW1lIH0gZnJvbSAnQGVtb3Rpb24vcmVhY3QnO1xuaW1wb3J0IHsgY3NzIH0gZnJvbSAnQGVtb3Rpb24vcmVhY3QnO1xuaW1wb3J0IENsb3NlSWNvbiBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL0Nsb3NlJztcbmltcG9ydCB7IEJveCwgSWNvbkJ1dHRvbiB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuaW1wb3J0IHsgVXNlclBlcm1pc3Npb25zR3VhcmQgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9wZXJtaXNzaW9ucy91c2VyLXBlcm1pc3Npb25zJztcbmltcG9ydCB7IFBhZ2VUaXRsZSB9IGZyb20gJy4uLy4uL2xheW91dHMnO1xuaW1wb3J0IHsgUGFnZUZvcmJpZGRlbiB9IGZyb20gJy4uLy4uL3Jlc3BvbnNlcyc7XG5cbmltcG9ydCB7IENyZWF0ZUVuZ2FnZW1lbnRGb3JtIH0gZnJvbSAnLi9mb3JtJztcblxuY29uc3Qgc3R5bGVzID0ge1xuICAgIHdyYXBwZXI6ICh0aGVtZTogVGhlbWUpID0+IGNzc2BcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbjogJHt0aGVtZS5zcGFjaW5nKDE4KX07XG4gICAgYCxcbiAgICByb290OiBjc3NgXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYCxcbiAgICB0aXRsZVJvb3Q6IGNzc2BcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGAsXG59O1xuXG5jb25zdCBDcmVhdGVQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICBjb25zdCBvbkNsb3NlID0gKCkgPT4gbmF2aWdhdGUoQVBQX1JPVVRFUy5FTkdBR0VNRU5ULlBBVEgpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPFVzZXJQZXJtaXNzaW9uc0d1YXJkXG4gICAgICAgICAgICBkZW55Q29tcG9uZW50PXs8UGFnZUZvcmJpZGRlbiAvPn1cbiAgICAgICAgICAgIGlzQWxsb3dlZD17KGJ1aWxkZXIpID0+IGJ1aWxkZXIuRXhhY3QoJ0VOR0FHRU1FTlRfQ1JFQVRFJyl9XG4gICAgICAgID5cbiAgICAgICAgICAgIDxCb3ggY3NzPXtzdHlsZXMud3JhcHBlcn0+XG4gICAgICAgICAgICAgICAgPEJveCBnYXA9ezE0fSBjc3M9e3N0eWxlcy5yb290fT5cbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VUaXRsZSB0aXRsZT1cItCh0L7Qt9C00LDQvdC40LUg0L/RgNC+0LXQutGC0LBcIiBjbGFzc2VzPXt7IHJvb3Q6IHN0eWxlcy50aXRsZVJvb3QgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBhcmlhLWxhYmVsPVwiY2xvc2VcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvc2VJY29uIGNvbG9yPVwic2Vjb25kYXJ5XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9QYWdlVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgIDxDcmVhdGVFbmdhZ2VtZW50Rm9ybSAvPlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvVXNlclBlcm1pc3Npb25zR3VhcmQ+XG4gICAgKTtcbn07XG5cbmV4cG9ydCB7IENyZWF0ZVBhZ2UgYXMgZGVmYXVsdCB9O1xuIl19 */",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  },
  titleRoot:  false ? 0 : {
    name: "jzhzn7-titleRoot",
    styles: "display:flex;justify-content:space-between;align-items:center;label:titleRoot;",
    map: "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvY3JlYXRlLXBhZ2UvaW5kZXgudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQTBCa0IiLCJmaWxlIjoiL1VzZXJzL2tyeWFidWtoaW4wMDEvRG9jdW1lbnRzL2F1cm9yYS9wYWNrYWdlcy9mZS1ob3N0LWFwcC9zcmMvYXBwL2NvbXBvbmVudHMvZW5nYWdlbWVudC9jcmVhdGUtcGFnZS9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBBUFBfUk9VVEVTIH0gZnJvbSAnQGF1cm9yYS9jb21tb24nO1xuaW1wb3J0IHR5cGUgeyBUaGVtZSB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IGNzcyB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCBDbG9zZUljb24gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9DbG9zZSc7XG5pbXBvcnQgeyBCb3gsIEljb25CdXR0b24gfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmltcG9ydCB7IFVzZXJQZXJtaXNzaW9uc0d1YXJkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvcGVybWlzc2lvbnMvdXNlci1wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBQYWdlVGl0bGUgfSBmcm9tICcuLi8uLi9sYXlvdXRzJztcbmltcG9ydCB7IFBhZ2VGb3JiaWRkZW4gfSBmcm9tICcuLi8uLi9yZXNwb25zZXMnO1xuXG5pbXBvcnQgeyBDcmVhdGVFbmdhZ2VtZW50Rm9ybSB9IGZyb20gJy4vZm9ybSc7XG5cbmNvbnN0IHN0eWxlcyA9IHtcbiAgICB3cmFwcGVyOiAodGhlbWU6IFRoZW1lKSA9PiBjc3NgXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBtYXJnaW46ICR7dGhlbWUuc3BhY2luZygxOCl9O1xuICAgIGAsXG4gICAgcm9vdDogY3NzYFxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGAsXG4gICAgdGl0bGVSb290OiBjc3NgXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBgLFxufTtcblxuY29uc3QgQ3JlYXRlUGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgY29uc3Qgb25DbG9zZSA9ICgpID0+IG5hdmlnYXRlKEFQUF9ST1VURVMuRU5HQUdFTUVOVC5QQVRIKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxVc2VyUGVybWlzc2lvbnNHdWFyZFxuICAgICAgICAgICAgZGVueUNvbXBvbmVudD17PFBhZ2VGb3JiaWRkZW4gLz59XG4gICAgICAgICAgICBpc0FsbG93ZWQ9eyhidWlsZGVyKSA9PiBidWlsZGVyLkV4YWN0KCdFTkdBR0VNRU5UX0NSRUFURScpfVxuICAgICAgICA+XG4gICAgICAgICAgICA8Qm94IGNzcz17c3R5bGVzLndyYXBwZXJ9PlxuICAgICAgICAgICAgICAgIDxCb3ggZ2FwPXsxNH0gY3NzPXtzdHlsZXMucm9vdH0+XG4gICAgICAgICAgICAgICAgICAgIDxQYWdlVGl0bGUgdGl0bGU9XCLQodC+0LfQtNCw0L3QuNC1INC/0YDQvtC10LrRgtCwXCIgY2xhc3Nlcz17eyByb290OiBzdHlsZXMudGl0bGVSb290IH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gYXJpYS1sYWJlbD1cImNsb3NlXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb3NlSWNvbiBjb2xvcj1cInNlY29uZGFyeVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvUGFnZVRpdGxlPlxuICAgICAgICAgICAgICAgICAgICA8Q3JlYXRlRW5nYWdlbWVudEZvcm0gLz5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L1VzZXJQZXJtaXNzaW9uc0d1YXJkPlxuICAgICk7XG59O1xuXG5leHBvcnQgeyBDcmVhdGVQYWdlIGFzIGRlZmF1bHQgfTtcbiJdfQ== */",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};
const CreatePage = () => {
  _s();
  const navigate = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_7__.useNavigate)();
  const onClose = () => navigate(_aurora_common__WEBPACK_IMPORTED_MODULE_1__.APP_ROUTES.ENGAGEMENT.PATH);
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_2__.UserPermissionsGuard, {
    denyComponent: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_responses__WEBPACK_IMPORTED_MODULE_4__.PageForbidden, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 28
    }, undefined),
    isAllowed: builder => builder.Exact('ENGAGEMENT_CREATE'),
    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
      css: styles.wrapper,
      children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
        gap: 14,
        css: styles.root,
        children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_layouts__WEBPACK_IMPORTED_MODULE_3__.PageTitle, {
          title: "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
          classes: {
            root: styles.titleRoot
          },
          children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__.IconButton, {
            "aria-label": "close",
            onClick: onClose,
            children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__["default"], {
              color: "secondary"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 21
        }, undefined), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(_form__WEBPACK_IMPORTED_MODULE_5__.CreateEngagementForm, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 40,
    columnNumber: 9
  }, undefined);
};
_s(CreatePage, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function () {
  return [react_router_dom__WEBPACK_IMPORTED_MODULE_7__.useNavigate];
});
_c = CreatePage;

var _c;
__webpack_require__.$Refresh$.register(_c, "CreatePage");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 537930:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   schema: () => (/* binding */ schema),
/* harmony export */   schemaDescription: () => (/* binding */ schemaDescription)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(421232);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);


const schema = yup__WEBPACK_IMPORTED_MODULE_0__.object({
  client: yup__WEBPACK_IMPORTED_MODULE_0__.object().required(),
  department: yup__WEBPACK_IMPORTED_MODULE_0__.object().required(),
  types: yup__WEBPACK_IMPORTED_MODULE_0__.array(yup__WEBPACK_IMPORTED_MODULE_0__.object()),
  reportingStandards: yup__WEBPACK_IMPORTED_MODULE_0__.array(yup__WEBPACK_IMPORTED_MODULE_0__.object()),
  verificationPeriod: yup__WEBPACK_IMPORTED_MODULE_0__.array(yup__WEBPACK_IMPORTED_MODULE_0__.string()),
  verificationYear: yup__WEBPACK_IMPORTED_MODULE_0__.number().nullable(),
  name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
}).required();

// TODO: найти способ сузить типы при доступе по ключу
const schemaDescription = schema.describe();

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 913164:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateName: () => (/* binding */ generateName)
/* harmony export */ });
/* harmony import */ var ramda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(290248);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(634984);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



/**
 * Генератор имени проекта по заданным полям
 */
const generateName = nameParts => {
  var _nameParts$client$nam, _nameParts$client, _nameParts$client2, _nameParts$workTypes, _nameParts$reportingS, _nameParts$verificati;
  return ramda__WEBPACK_IMPORTED_MODULE_0__.filter(ramda__WEBPACK_IMPORTED_MODULE_0__.compose(ramda__WEBPACK_IMPORTED_MODULE_0__.not, ramda__WEBPACK_IMPORTED_MODULE_0__.isNil), ramda__WEBPACK_IMPORTED_MODULE_0__.filter(ramda__WEBPACK_IMPORTED_MODULE_0__.compose(ramda__WEBPACK_IMPORTED_MODULE_0__.not, ramda__WEBPACK_IMPORTED_MODULE_0__.isEmpty), [(_nameParts$client$nam = (_nameParts$client = nameParts.client) == null ? void 0 : _nameParts$client.name) != null ? _nameParts$client$nam : (_nameParts$client2 = nameParts.client) == null ? void 0 : _nameParts$client2.nameEn, (_nameParts$workTypes = nameParts.workTypes) == null ? void 0 : _nameParts$workTypes.map(workType => workType.nameShort), (_nameParts$reportingS = nameParts.reportingStandards) == null ? void 0 : _nameParts$reportingS.map(type => type.nameShort), (_nameParts$verificati = nameParts.verificationPeriods) == null ? void 0 : _nameParts$verificati.map(key => {
    var _VERIFICATION_PERIODS;
    return (_VERIFICATION_PERIODS = _consts__WEBPACK_IMPORTED_MODULE_1__.VERIFICATION_PERIODS.find(f => f.id === key)) == null ? void 0 : _VERIFICATION_PERIODS.name;
  }), nameParts.verificationYear]).map(item => Array.isArray(item) ? item.join(', ') : item)).join(' / ');
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 272713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getClientNameView: () => (/* binding */ getClientNameView)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

/**
 * Функция отображение имени клиента (клиент аудита)
 */
function getClientNameView(client) {
  var _client$name;
  return `${(_client$name = client.name) != null ? _client$name : client.nameEn}`;
}

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

}]);