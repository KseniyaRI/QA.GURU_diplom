"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["list-page"],{

/***/ 939513:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BenchmarksAutocomplete: () => (/* binding */ BenchmarksAutocomplete),
/* harmony export */   OTHER_ITEM: () => (/* binding */ OTHER_ITEM)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);





const OTHER_ITEM = {
  id: 'OTHER',
  name: 'Иное'
};
const BenchmarksAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_3__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_2__.useGetBenchmarksQuery, data => {
  const toFormat = data == null ? void 0 : data.data.map(item => ({
    id: item.id,
    name: item.name
  }));
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_2__.getDictionaryFromResponse)({
    data: toFormat ? [...toFormat, OTHER_ITEM] : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 857481:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CLIENT_INPUT_SEARCH_MIN_CHARS: () => (/* binding */ CLIENT_INPUT_SEARCH_MIN_CHARS),
/* harmony export */   ClientsInputAutocomplete: () => (/* binding */ ClientsInputAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const CLIENT_INPUT_SEARCH_MIN_CHARS = 3;
const ClientsInputAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withLazyQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.getClientsByParams, search => ({
  search,
  hasClientCode: true
}), r => {
  var _r$data$items, _r$data;
  return (_r$data$items = r == null || (_r$data = r.data) == null ? void 0 : _r$data.items) != null ? _r$data$items : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 570799:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlBusinessProcessesAutocomplete: () => (/* binding */ ControlBusinessProcessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ControlBusinessProcessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetControlBusinessProcessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 259535:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlBusinessSubprocessesAutocomplete: () => (/* binding */ ControlBusinessSubprocessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ControlBusinessSubprocessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetControlBusinessSubprocessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 82539:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CONTROL_AUTOMATION_LEVEL_OPTIONS: () => (/* binding */ CONTROL_AUTOMATION_LEVEL_OPTIONS),
/* harmony export */   CONTROL_FREQUENCY_OPTIONS: () => (/* binding */ CONTROL_FREQUENCY_OPTIONS),
/* harmony export */   CONTROL_IT_DEPENDENCIES_OPTIONS: () => (/* binding */ CONTROL_IT_DEPENDENCIES_OPTIONS),
/* harmony export */   CONTROL_NATURE_LEVEL_OPTIONS: () => (/* binding */ CONTROL_NATURE_LEVEL_OPTIONS),
/* harmony export */   CONTROL_TYPE_OPTIONS: () => (/* binding */ CONTROL_TYPE_OPTIONS),
/* harmony export */   INFORMATION_TESTING_PURPOSES: () => (/* binding */ INFORMATION_TESTING_PURPOSES)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

const CONTROL_AUTOMATION_LEVEL_OPTIONS = {
  AUTOMATED: 'Автоматизированное',
  IT_DEPENDENT_COMPLETELY_MANUAL: 'Зависимое от ИТ, осуществляемое вручную',
  COMPLETELY_MANUAL: 'Осуществляемое вручную'
};
const CONTROL_NATURE_LEVEL_OPTIONS = {
  DETECTING: 'Обнаруживающее',
  WARNING: 'Предупреждающее'
};
const CONTROL_TYPE_OPTIONS = {
  DIRECT_CONTROLS_AT_ORGANIZATIONAL_LEVEL: 'Прямые средства контроля на уровне организации в целом',
  DIRECT_CONTROLS_AT_OPERATIONAL_LEVEL: 'Прямые средства контроля на уровне операций',
  COMMON_CONTROLS_IN_INFORMATION_SYSTEMS: 'Общие средства контроля в информационных системах'
};
const INFORMATION_TESTING_PURPOSES = {
  C: 'П',
  A: 'Т',
  V: 'Д',
  R: 'ОД'
};
const CONTROL_FREQUENCY_OPTIONS = {
  SEVERAL_TIMES_A_DAY: 'Несколько раз в день',
  DAILY: 'Ежедневно',
  WEEKLY: 'Еженедельно',
  MONTHLY: 'Ежемесячно',
  QUARTERLY: 'Ежеквартально',
  ANNUALLY: 'Ежегодно',
  OTHER: 'Прочее'
};
const CONTROL_IT_DEPENDENCIES_OPTIONS = {
  AUTOMATED_CONTROL: 'Автоматизированное средство контроля',
  AUTOMATED_INTERFACE: 'Автоматизированный интерфейс',
  AUTOMATED_CALCULATION: 'Автоматизированный расчет',
  SECURITY: 'Безопасность',
  IT_INDEPENDENT: 'Зависимость от информационных технологий отсутствует',
  REPORT_GENERATED_BY_ACCOUNTING_PROGRAM: 'Отчет, сформированный бухгалтерской программой'
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 768514:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DepartmentsAutocomplete: () => (/* binding */ DepartmentsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const DepartmentsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetDepartmentsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 860213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EngagementStandardsAutocomplete: () => (/* binding */ EngagementStandardsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const EngagementStandardsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetEngagementStandardsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 206546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EstimateValuesAutocomplete: () => (/* binding */ EstimateValuesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_engagement__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(245303);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const EstimateValuesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_engagement__WEBPACK_IMPORTED_MODULE_1__.useGetEstimateValuesQuery, data => {
  var _data$data$items, _data$data;
  return (_data$data$items = data == null || (_data$data = data.data) == null ? void 0 : _data$data.items) != null ? _data$data$items : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 521123:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fsli1SAutocomplete: () => (/* binding */ Fsli1SAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const Fsli1SAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsli1SQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 996846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fsli2Autocomplete: () => (/* binding */ Fsli2Autocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const Fsli2Autocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsli2SQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 280308:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FsliBusinessProcessesAutocomplete: () => (/* binding */ FsliBusinessProcessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const FsliBusinessProcessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetFsliBusinessProcessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 59353:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FsliAutocomplete: () => (/* binding */ FsliAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _features_repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(586328);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const FsliAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_repository__WEBPACK_IMPORTED_MODULE_1__.useGetFslIsQuery, data => {
  var _data$data$items;
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse)({
    data: (_data$data$items = data == null ? void 0 : data.data.items) != null ? _data$data$items : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 648105:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BenchmarksAutocomplete: () => (/* reexport safe */ _benchmarks__WEBPACK_IMPORTED_MODULE_18__.BenchmarksAutocomplete),
/* harmony export */   CLIENT_INPUT_SEARCH_MIN_CHARS: () => (/* reexport safe */ _clients__WEBPACK_IMPORTED_MODULE_0__.CLIENT_INPUT_SEARCH_MIN_CHARS),
/* harmony export */   CONTROL_AUTOMATION_LEVEL_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_AUTOMATION_LEVEL_OPTIONS),
/* harmony export */   CONTROL_FREQUENCY_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_FREQUENCY_OPTIONS),
/* harmony export */   CONTROL_IT_DEPENDENCIES_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_IT_DEPENDENCIES_OPTIONS),
/* harmony export */   CONTROL_NATURE_LEVEL_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_NATURE_LEVEL_OPTIONS),
/* harmony export */   CONTROL_TYPE_OPTIONS: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.CONTROL_TYPE_OPTIONS),
/* harmony export */   ClientsInputAutocomplete: () => (/* reexport safe */ _clients__WEBPACK_IMPORTED_MODULE_0__.ClientsInputAutocomplete),
/* harmony export */   ControlBusinessProcessesAutocomplete: () => (/* reexport safe */ _control_business_processes__WEBPACK_IMPORTED_MODULE_14__.ControlBusinessProcessesAutocomplete),
/* harmony export */   ControlBusinessSubprocessesAutocomplete: () => (/* reexport safe */ _control_business_subprocesses__WEBPACK_IMPORTED_MODULE_15__.ControlBusinessSubprocessesAutocomplete),
/* harmony export */   DepartmentsAutocomplete: () => (/* reexport safe */ _departments__WEBPACK_IMPORTED_MODULE_1__.DepartmentsAutocomplete),
/* harmony export */   EngagementStandardsAutocomplete: () => (/* reexport safe */ _engagement_standards__WEBPACK_IMPORTED_MODULE_2__.EngagementStandardsAutocomplete),
/* harmony export */   EstimateValuesAutocomplete: () => (/* reexport safe */ _estimate_values__WEBPACK_IMPORTED_MODULE_8__.EstimateValuesAutocomplete),
/* harmony export */   Fsli1SAutocomplete: () => (/* reexport safe */ _fsli_1__WEBPACK_IMPORTED_MODULE_9__.Fsli1SAutocomplete),
/* harmony export */   Fsli2Autocomplete: () => (/* reexport safe */ _fsli_2__WEBPACK_IMPORTED_MODULE_10__.Fsli2Autocomplete),
/* harmony export */   FsliAutocomplete: () => (/* reexport safe */ _fsli__WEBPACK_IMPORTED_MODULE_11__.FsliAutocomplete),
/* harmony export */   FsliBusinessProcessesAutocomplete: () => (/* reexport safe */ _fsli_business_processes__WEBPACK_IMPORTED_MODULE_13__.FsliBusinessProcessesAutocomplete),
/* harmony export */   INFORMATION_TESTING_PURPOSES: () => (/* reexport safe */ _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__.INFORMATION_TESTING_PURPOSES),
/* harmony export */   IndustriesAutocomplete: () => (/* reexport safe */ _industries__WEBPACK_IMPORTED_MODULE_12__.IndustriesAutocomplete),
/* harmony export */   MaterialityFactorsAutocomplete: () => (/* reexport safe */ _materiality_factors__WEBPACK_IMPORTED_MODULE_19__.MaterialityFactorsAutocomplete),
/* harmony export */   OTHER_ITEM: () => (/* reexport safe */ _benchmarks__WEBPACK_IMPORTED_MODULE_18__.OTHER_ITEM),
/* harmony export */   PrerequisitesAutocomplete: () => (/* reexport safe */ _prerequisite__WEBPACK_IMPORTED_MODULE_3__.PrerequisitesAutocomplete),
/* harmony export */   ReportTypesAutocomplete: () => (/* reexport safe */ _report_types__WEBPACK_IMPORTED_MODULE_4__.ReportTypesAutocomplete),
/* harmony export */   ReportingStandardsAutocomplete: () => (/* reexport safe */ _reporting_standards__WEBPACK_IMPORTED_MODULE_5__.ReportingStandardsAutocomplete),
/* harmony export */   ReportingTypesAutocomplete: () => (/* reexport safe */ _reporting_types__WEBPACK_IMPORTED_MODULE_6__.ReportingTypesAutocomplete),
/* harmony export */   RiskSubprocessesAutocomplete: () => (/* reexport safe */ _risk_subprocesses__WEBPACK_IMPORTED_MODULE_16__.RiskSubprocessesAutocomplete),
/* harmony export */   WorkTypesAutocomplete: () => (/* reexport safe */ _work_types__WEBPACK_IMPORTED_MODULE_7__.WorkTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _clients__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(857481);
/* harmony import */ var _departments__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(768514);
/* harmony import */ var _engagement_standards__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(860213);
/* harmony import */ var _prerequisite__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(863443);
/* harmony import */ var _report_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(858783);
/* harmony import */ var _reporting_standards__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(814672);
/* harmony import */ var _reporting_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(128059);
/* harmony import */ var _work_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(599756);
/* harmony import */ var _estimate_values__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(206546);
/* harmony import */ var _fsli_1__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(521123);
/* harmony import */ var _fsli_2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(996846);
/* harmony import */ var _fsli__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59353);
/* harmony import */ var _industries__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5979);
/* harmony import */ var _fsli_business_processes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(280308);
/* harmony import */ var _control_business_processes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(570799);
/* harmony import */ var _control_business_subprocesses__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(259535);
/* harmony import */ var _risk_subprocesses__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(432092);
/* harmony import */ var _controls_static_dictionaries__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(82539);
/* harmony import */ var _benchmarks__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(939513);
/* harmony import */ var _materiality_factors__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(517323);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);























const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 5979:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IndustriesAutocomplete: () => (/* binding */ IndustriesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const IndustriesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetIndustriesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 517323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MaterialityFactorsAutocomplete: () => (/* binding */ MaterialityFactorsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const MaterialityFactorsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetMaterialityFactorsQuery, data => {
  var _data$data;
  return (0,_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse)({
    data: (_data$data = data == null ? void 0 : data.data) != null ? _data$data : []
  });
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 863443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrerequisitesAutocomplete: () => (/* binding */ PrerequisitesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const PrerequisitesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetPrerequisitesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 858783:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportTypesAutocomplete: () => (/* binding */ ReportTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const ReportTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.useGetReportTypesQuery, r => {
  var _r$data;
  return (_r$data = r == null ? void 0 : r.data) != null ? _r$data : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 814672:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportingStandardsAutocomplete: () => (/* binding */ ReportingStandardsAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const ReportingStandardsAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetReportingStandardsQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 128059:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportingTypesAutocomplete: () => (/* binding */ ReportingTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659980);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);




const ReportingTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_2__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_1__.useGetReportingTypesQuery, r => {
  var _r$data;
  return (_r$data = r == null ? void 0 : r.data) != null ? _r$data : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_0__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 432092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RiskSubprocessesAutocomplete: () => (/* binding */ RiskSubprocessesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const RiskSubprocessesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetRiskSubprocessesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 97221:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   USER_INPUT_SEARCH_MIN_CHARS: () => (/* binding */ USER_INPUT_SEARCH_MIN_CHARS),
/* harmony export */   UserInputAutocomplete: () => (/* binding */ UserInputAutocomplete)
/* harmony export */ });
/* harmony import */ var _aurora_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(558447);
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(659980);
/* harmony import */ var _features_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(705199);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);





const USER_INPUT_SEARCH_MIN_CHARS = 3;
const UserInputAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_3__.withLazyQueryAutocomplete)(_features_user__WEBPACK_IMPORTED_MODULE_2__.getUsersByParameters, search => ({
  search,
  roles: [_aurora_common__WEBPACK_IMPORTED_MODULE_0__.EUserRole.USER]
}),
// TODO переделать на permission, после реализации бэка
r => {
  var _r$data;
  return (_r$data = r == null ? void 0 : r.data) != null ? _r$data : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_1__.empty;
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 599756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WorkTypesAutocomplete: () => (/* binding */ WorkTypesAutocomplete)
/* harmony export */ });
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(603804);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(868845);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const WorkTypesAutocomplete = (0,_autocomplete__WEBPACK_IMPORTED_MODULE_1__.withQueryAutocomplete)(_features_dictionary__WEBPACK_IMPORTED_MODULE_0__.useGetWorkTypesQuery, _features_dictionary__WEBPACK_IMPORTED_MODULE_0__.getDictionaryFromResponse);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 35015:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateEngagement: () => (/* binding */ CreateEngagement)
/* harmony export */ });
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(154466);
/* harmony import */ var _services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3259);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/create-engagement/index.tsx";





const CreateEngagement = () => {
  const pagePath = (0,_routes__WEBPACK_IMPORTED_MODULE_1__.getCreateEngagementPage)();
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_2__.UserPermissionsGuard, {
    isAllowed: builder => builder.Exact('ENGAGEMENT_CREATE'),
    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
      component: _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_0__.AuRouterLink,
      to: pagePath,
      underline: "none",
      color: "primary",
      size: "medium",
      variant: "contained",
      children: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 9
  }, undefined);
};
_c = CreateEngagement;
var _c;
__webpack_require__.$Refresh$.register(_c, "CreateEngagement");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 885206:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClientFilter: () => (/* binding */ ClientFilter)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(796104);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(130935);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(668291);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var ramda__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(290248);
/* harmony import */ var _features_dictionary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(603804);
/* harmony import */ var _features_dictionary_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(272713);
/* harmony import */ var _routes_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(447177);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(868845);
/* harmony import */ var _dictionaries__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(648105);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(634984);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/filters/client-filter/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }

















var _ref =  false ? 0 : {
  name: "hsdxxd-ClientFilter",
  styles: "width:110px;label:ClientFilter;",
  map: "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvY2xpZW50LWZpbHRlci9pbmRleC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBOEVnQyIsImZpbGUiOiIvVXNlcnMva3J5YWJ1a2hpbjAwMS9Eb2N1bWVudHMvYXVyb3JhL3BhY2thZ2VzL2ZlLWhvc3QtYXBwL3NyYy9hcHAvY29tcG9uZW50cy9lbmdhZ2VtZW50L2xpc3QtcGFnZS9maWx0ZXJzL2NsaWVudC1maWx0ZXIvaW5kZXgudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgQXVUZXh0RmllbGQsIEF1VG9vbHRpcCB9IGZyb20gJ0BhdXJvcmEvdWkta2l0JztcbmltcG9ydCB7IEJveCwgQ2hpcCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0ICogYXMgUiBmcm9tICdyYW1kYSc7XG5cbmltcG9ydCB7IGdldENsaWVudHNCeVBhcmFtcyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2ZlYXR1cmVzL2RpY3Rpb25hcnknO1xuaW1wb3J0IHR5cGUgeyBUQ2xpZW50IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZmVhdHVyZXMvZGljdGlvbmFyeSc7XG5pbXBvcnQgeyBnZXRDbGllbnROYW1lVmlldyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2ZlYXR1cmVzL2RpY3Rpb25hcnkvdXRpbHMnO1xuaW1wb3J0IHsgdXNlUXVlcnlQYXJhbXMgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9yb3V0ZXMvaG9va3MnO1xuaW1wb3J0IHsgZm9ybWF0QXV0b2NvbXBsZXRlUGxhY2Vob2xkZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9hdXRvY29tcGxldGUnO1xuaW1wb3J0IHsgQ2xpZW50c0lucHV0QXV0b2NvbXBsZXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZGljdGlvbmFyaWVzJztcbmltcG9ydCB7IEZJRUxEX05BTUVTLCBGSUVMRF9TSVpFLCBGSUxURVJfU1RZTEUgfSBmcm9tICcuLi8uLi8uLi9jb25zdHMnO1xuaW1wb3J0IHR5cGUgeyBURW5nYWdlbWVudFF1ZXJ5UGFyYW1zIH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMnO1xuXG5pbnRlcmZhY2UgSVByb3BzIHtcbiAgICBvbkNoYW5nZTogKHZhbHVlOiBzdHJpbmdbXSkgPT4gdm9pZDtcbiAgICBkaXNhYmxlZDogYm9vbGVhbjtcbiAgICB3aWR0aDogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgQ2xpZW50RmlsdGVyOiBSZWFjdC5GQzxJUHJvcHM+ID0gKHsgb25DaGFuZ2UsIGRpc2FibGVkLCB3aWR0aCB9KSA9PiB7XG4gICAgY29uc3QgeyBnZXRRdWVyeVBhcmFtcyB9ID0gdXNlUXVlcnlQYXJhbXMoKTtcbiAgICBjb25zdCBbZ2V0Q2xpZW50c10gPSBnZXRDbGllbnRzQnlQYXJhbXMudXNlTGF6eVF1ZXJ5KCk7XG4gICAgY29uc3QgW2NsaWVudHMsIHNldENsaWVudHNdID0gUmVhY3QudXNlU3RhdGU8VENsaWVudFtdPihbXSk7XG5cbiAgICBjb25zdCBjbGllbnRzSWRzID0gZ2V0UXVlcnlQYXJhbXM8VEVuZ2FnZW1lbnRRdWVyeVBhcmFtcz4oKT8uY2xpZW50SWRzIHx8IFtdO1xuXG4gICAgY29uc3QgaGFuZGxlUXVlcnlQYXJhbXNDaGFuZ2UgPSAobmV4dENsaWVudHM6IFRDbGllbnRbXSkgPT4ge1xuICAgICAgICBjb25zdCBpZHMgPSBuZXh0Q2xpZW50cy5tYXAoKGkpID0+IGkuaWQpIHx8IFtdO1xuXG4gICAgICAgIG9uQ2hhbmdlKGlkcyk7XG4gICAgfTtcblxuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChjbGllbnRzSWRzPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGdldENsaWVudHMoeyBpZHM6IGNsaWVudHNJZHMgfSkudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgY2xpZW50c0J5SWRzID1cbiAgICAgICAgICAgICAgICAgICAgcmVzPy5kYXRhPy5kYXRhLml0ZW1zPy5yZWR1Y2U8VENsaWVudFtdPigoYWNjLCBuZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2xpZW50c0lkcy5pbmNsdWRlcyhuZXh0LmlkKSkgYWNjLnB1c2gobmV4dCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2M7XG4gICAgICAgICAgICAgICAgICAgIH0sIFtdKSB8fCBbXTtcblxuICAgICAgICAgICAgICAgIHNldENsaWVudHMoY2xpZW50c0J5SWRzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Ugc2V0Q2xpZW50cyhbXSk7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICB9LCBbY2xpZW50c0lkcz8ubGVuZ3RoXSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8Q2xpZW50c0lucHV0QXV0b2NvbXBsZXRlXG4gICAgICAgICAgICBpZD1cImNsaWVudHNcIlxuICAgICAgICAgICAgdmFsdWU9e2NsaWVudHN9XG4gICAgICAgICAgICBvbkNoYW5nZT17KF8sIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgaGFuZGxlUXVlcnlQYXJhbXNDaGFuZ2UodmFsdWUpO1xuICAgICAgICAgICAgICAgIHNldENsaWVudHModmFsdWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG1pbklucHV0PXszfVxuICAgICAgICAgICAgbGltaXRUYWdzPXsyfVxuICAgICAgICAgICAgc2l6ZT17RklFTERfU0laRX1cbiAgICAgICAgICAgIG9wZW5PbkZvY3VzPXtmYWxzZX1cbiAgICAgICAgICAgIHNlbGVjdE9uRm9jdXM9e2ZhbHNlfVxuICAgICAgICAgICAgcmVuZGVySW5wdXQ9eyh0ZXh0RmllbGRQYXJhbXMpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8QXVUZXh0RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgIHsuLi50ZXh0RmllbGRQYXJhbXN9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17Zm9ybWF0QXV0b2NvbXBsZXRlUGxhY2Vob2xkZXIoRklFTERfTkFNRVMuY2xpZW50LCBjbGllbnRzKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICByZW5kZXJUYWdzPXsodmFsLCBnZXRUYWdQcm9wcykgPT5cbiAgICAgICAgICAgICAgICB2YWwubWFwKChvcHRpb24sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxBdVRvb2x0aXAga2V5PXtpbmRleH0gZGlzYWJsZUludGVyYWN0aXZlIHRpdGxlPXtnZXRDbGllbnROYW1lVmlldyhvcHRpb24pfSBwbGFjZW1lbnQ9XCJ0b3BcIiBhcnJvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoaXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLmdldFRhZ1Byb3BzKHsgaW5kZXggfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNzcz17eyB3aWR0aDogJzExMHB4JyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17Z2V0Q2xpZW50TmFtZVZpZXcob3B0aW9uKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICAgIDwvQXVUb29sdGlwPlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBnZXRPcHRpb25MYWJlbD17Z2V0Q2xpZW50TmFtZVZpZXd9XG4gICAgICAgICAgICBpc09wdGlvbkVxdWFsVG9WYWx1ZT17Ui5lcVByb3BzKCdpZCcpfVxuICAgICAgICAgICAgbXVsdGlwbGVcbiAgICAgICAgICAgIGNzcz17W3sgd2lkdGggfSwgRklMVEVSX1NUWUxFXX1cbiAgICAgICAgICAgIGRpc2FibGVDbG9zZU9uU2VsZWN0XG4gICAgICAgICAgICBkaXNhYmxlQ2xlYXJhYmxlXG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXX0= */",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
const ClientFilter = ({
  onChange,
  disabled,
  width
}) => {
  _s();
  var _getQueryParams;
  const {
    getQueryParams
  } = (0,_routes_hooks__WEBPACK_IMPORTED_MODULE_11__.useQueryParams)();
  const [getClients] = _features_dictionary__WEBPACK_IMPORTED_MODULE_9__.getClientsByParams.useLazyQuery();
  const [clients, setClients] = react__WEBPACK_IMPORTED_MODULE_6___default().useState([]);
  const clientsIds = ((_getQueryParams = getQueryParams()) == null ? void 0 : _getQueryParams.clientIds) || [];
  const handleQueryParamsChange = nextClients => {
    const ids = nextClients.map(i => i.id) || [];
    onChange(ids);
  };
  react__WEBPACK_IMPORTED_MODULE_6___default().useEffect(() => {
    if (clientsIds != null && clientsIds.length) {
      getClients({
        ids: clientsIds
      }).then(res => {
        var _res$data;
        const clientsByIds = (res == null || (_res$data = res.data) == null || (_res$data = _res$data.data.items) == null ? void 0 : _res$data.reduce((acc, next) => {
          if (clientsIds.includes(next.id)) acc.push(next);
          return acc;
        }, [])) || [];
        setClients(clientsByIds);
      });
    } else setClients([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientsIds == null ? void 0 : clientsIds.length]);
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_dictionaries__WEBPACK_IMPORTED_MODULE_13__.ClientsInputAutocomplete, {
    id: "clients",
    value: clients,
    onChange: (_, value) => {
      handleQueryParamsChange(value);
      setClients(value);
    },
    minInput: 3,
    limitTags: 2,
    size: _consts__WEBPACK_IMPORTED_MODULE_14__.FIELD_SIZE,
    openOnFocus: false,
    selectOnFocus: false,
    renderInput: textFieldParams => {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTextField, Object.assign({}, textFieldParams, {
        placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_12__.formatAutocompletePlaceholder)(_consts__WEBPACK_IMPORTED_MODULE_14__.FIELD_NAMES.client, clients),
        size: "small"
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 21
      }, undefined);
    },
    renderTags: (val, getTagProps) => val.map((option, index) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_7__.AuTooltip, {
      disableInteractive: true,
      title: (0,_features_dictionary_utils__WEBPACK_IMPORTED_MODULE_10__.getClientNameView)(option),
      placement: "top",
      arrow: true,
      children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_16__.Box, {
        children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_16__.Chip, Object.assign({}, getTagProps({
          index
        }), {
          css: _ref,
          size: "small",
          label: (0,_features_dictionary_utils__WEBPACK_IMPORTED_MODULE_10__.getClientNameView)(option)
        }), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 29
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 25
      }, undefined)
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 21
    }, undefined)),
    getOptionLabel: _features_dictionary_utils__WEBPACK_IMPORTED_MODULE_10__.getClientNameView,
    isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_8__.eqProps('id'),
    multiple: true,
    css: [{
      width
    }, _consts__WEBPACK_IMPORTED_MODULE_14__.FILTER_STYLE,  false ? 0 : ";label:ClientFilter;",  false ? 0 : "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvY2xpZW50LWZpbHRlci9pbmRleC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBeUZZIiwiZmlsZSI6Ii9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvY2xpZW50LWZpbHRlci9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBBdVRleHRGaWVsZCwgQXVUb29sdGlwIH0gZnJvbSAnQGF1cm9yYS91aS1raXQnO1xuaW1wb3J0IHsgQm94LCBDaGlwIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgKiBhcyBSIGZyb20gJ3JhbWRhJztcblxuaW1wb3J0IHsgZ2V0Q2xpZW50c0J5UGFyYW1zIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZmVhdHVyZXMvZGljdGlvbmFyeSc7XG5pbXBvcnQgdHlwZSB7IFRDbGllbnQgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9mZWF0dXJlcy9kaWN0aW9uYXJ5JztcbmltcG9ydCB7IGdldENsaWVudE5hbWVWaWV3IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZmVhdHVyZXMvZGljdGlvbmFyeS91dGlscyc7XG5pbXBvcnQgeyB1c2VRdWVyeVBhcmFtcyB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3JvdXRlcy9ob29rcyc7XG5pbXBvcnQgeyBmb3JtYXRBdXRvY29tcGxldGVQbGFjZWhvbGRlciB9IGZyb20gJy4uLy4uLy4uLy4uL2F1dG9jb21wbGV0ZSc7XG5pbXBvcnQgeyBDbGllbnRzSW5wdXRBdXRvY29tcGxldGUgfSBmcm9tICcuLi8uLi8uLi8uLi9kaWN0aW9uYXJpZXMnO1xuaW1wb3J0IHsgRklFTERfTkFNRVMsIEZJRUxEX1NJWkUsIEZJTFRFUl9TVFlMRSB9IGZyb20gJy4uLy4uLy4uL2NvbnN0cyc7XG5pbXBvcnQgdHlwZSB7IFRFbmdhZ2VtZW50UXVlcnlQYXJhbXMgfSBmcm9tICcuLi8uLi8uLi90eXBlcyc7XG5cbmludGVyZmFjZSBJUHJvcHMge1xuICAgIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZ1tdKSA9PiB2b2lkO1xuICAgIGRpc2FibGVkOiBib29sZWFuO1xuICAgIHdpZHRoOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBDbGllbnRGaWx0ZXI6IFJlYWN0LkZDPElQcm9wcz4gPSAoeyBvbkNoYW5nZSwgZGlzYWJsZWQsIHdpZHRoIH0pID0+IHtcbiAgICBjb25zdCB7IGdldFF1ZXJ5UGFyYW1zIH0gPSB1c2VRdWVyeVBhcmFtcygpO1xuICAgIGNvbnN0IFtnZXRDbGllbnRzXSA9IGdldENsaWVudHNCeVBhcmFtcy51c2VMYXp5UXVlcnkoKTtcbiAgICBjb25zdCBbY2xpZW50cywgc2V0Q2xpZW50c10gPSBSZWFjdC51c2VTdGF0ZTxUQ2xpZW50W10+KFtdKTtcblxuICAgIGNvbnN0IGNsaWVudHNJZHMgPSBnZXRRdWVyeVBhcmFtczxURW5nYWdlbWVudFF1ZXJ5UGFyYW1zPigpPy5jbGllbnRJZHMgfHwgW107XG5cbiAgICBjb25zdCBoYW5kbGVRdWVyeVBhcmFtc0NoYW5nZSA9IChuZXh0Q2xpZW50czogVENsaWVudFtdKSA9PiB7XG4gICAgICAgIGNvbnN0IGlkcyA9IG5leHRDbGllbnRzLm1hcCgoaSkgPT4gaS5pZCkgfHwgW107XG5cbiAgICAgICAgb25DaGFuZ2UoaWRzKTtcbiAgICB9O1xuXG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNsaWVudHNJZHM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgZ2V0Q2xpZW50cyh7IGlkczogY2xpZW50c0lkcyB9KS50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjbGllbnRzQnlJZHMgPVxuICAgICAgICAgICAgICAgICAgICByZXM/LmRhdGE/LmRhdGEuaXRlbXM/LnJlZHVjZTxUQ2xpZW50W10+KChhY2MsIG5leHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjbGllbnRzSWRzLmluY2x1ZGVzKG5leHQuaWQpKSBhY2MucHVzaChuZXh0KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgICAgICAgICAgICAgICAgfSwgW10pIHx8IFtdO1xuXG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50cyhjbGllbnRzQnlJZHMpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBzZXRDbGllbnRzKFtdKTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgIH0sIFtjbGllbnRzSWRzPy5sZW5ndGhdKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxDbGllbnRzSW5wdXRBdXRvY29tcGxldGVcbiAgICAgICAgICAgIGlkPVwiY2xpZW50c1wiXG4gICAgICAgICAgICB2YWx1ZT17Y2xpZW50c31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoXywgdmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICBoYW5kbGVRdWVyeVBhcmFtc0NoYW5nZSh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50cyh2YWx1ZSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgbWluSW5wdXQ9ezN9XG4gICAgICAgICAgICBsaW1pdFRhZ3M9ezJ9XG4gICAgICAgICAgICBzaXplPXtGSUVMRF9TSVpFfVxuICAgICAgICAgICAgb3Blbk9uRm9jdXM9e2ZhbHNlfVxuICAgICAgICAgICAgc2VsZWN0T25Gb2N1cz17ZmFsc2V9XG4gICAgICAgICAgICByZW5kZXJJbnB1dD17KHRleHRGaWVsZFBhcmFtcykgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxBdVRleHRGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgey4uLnRleHRGaWVsZFBhcmFtc31cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmb3JtYXRBdXRvY29tcGxldGVQbGFjZWhvbGRlcihGSUVMRF9OQU1FUy5jbGllbnQsIGNsaWVudHMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIHJlbmRlclRhZ3M9eyh2YWwsIGdldFRhZ1Byb3BzKSA9PlxuICAgICAgICAgICAgICAgIHZhbC5tYXAoKG9wdGlvbiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPEF1VG9vbHRpcCBrZXk9e2luZGV4fSBkaXNhYmxlSW50ZXJhY3RpdmUgdGl0bGU9e2dldENsaWVudE5hbWVWaWV3KG9wdGlvbil9IHBsYWNlbWVudD1cInRvcFwiIGFycm93PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hpcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4uZ2V0VGFnUHJvcHMoeyBpbmRleCB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3NzPXt7IHdpZHRoOiAnMTEwcHgnIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtnZXRDbGllbnROYW1lVmlldyhvcHRpb24pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgPC9BdVRvb2x0aXA+XG4gICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGdldE9wdGlvbkxhYmVsPXtnZXRDbGllbnROYW1lVmlld31cbiAgICAgICAgICAgIGlzT3B0aW9uRXF1YWxUb1ZhbHVlPXtSLmVxUHJvcHMoJ2lkJyl9XG4gICAgICAgICAgICBtdWx0aXBsZVxuICAgICAgICAgICAgY3NzPXtbeyB3aWR0aCB9LCBGSUxURVJfU1RZTEVdfVxuICAgICAgICAgICAgZGlzYWJsZUNsb3NlT25TZWxlY3RcbiAgICAgICAgICAgIGRpc2FibGVDbGVhcmFibGVcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdfQ== */"],
    disableCloseOnSelect: true,
    disableClearable: true,
    disabled: disabled
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 52,
    columnNumber: 9
  }, undefined);
};
_s(ClientFilter, "1YIJ50LaCjI6OkxVdPeI+t8+4Hs=", false, function () {
  return [_routes_hooks__WEBPACK_IMPORTED_MODULE_11__.useQueryParams, _features_dictionary__WEBPACK_IMPORTED_MODULE_9__.getClientsByParams.useLazyQuery];
});
_c = ClientFilter;
var _c;
__webpack_require__.$Refresh$.register(_c, "ClientFilter");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 849853:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FinancialYearsFilter: () => (/* binding */ FinancialYearsFilter)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(673444);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(868845);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(634984);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/filters/financial-years-filter/index.tsx";








const OPTIONS = (0,_aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_2__.getYearsFromStartYear)(_consts__WEBPACK_IMPORTED_MODULE_5__.START_YEAR, _consts__WEBPACK_IMPORTED_MODULE_5__.ADDITIONAL_YEARS);
_c = OPTIONS;
const FinancialYearsFilter = ({
  value: _value = [],
  onChange,
  disabled,
  width
}) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Autocomplete, {
  value: _value,
  size: "small",
  css: [{
    width
  }, _consts__WEBPACK_IMPORTED_MODULE_5__.FILTER_STYLE,  false ? 0 : ";label:FinancialYearsFilter;",  false ? 0 : "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvZmluYW5jaWFsLXllYXJzLWZpbHRlci9pbmRleC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBc0JRIiwiZmlsZSI6Ii9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvZmluYW5jaWFsLXllYXJzLWZpbHRlci9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBnZXRZZWFyc0Zyb21TdGFydFllYXIsIHRvRm9ybWF0RmluYW5jaWFsWWVhciB9IGZyb20gJ0BhdXJvcmEvZmUtc2RrL251bWJlcnMnO1xuaW1wb3J0IHsgQXVUZXh0RmllbGQgfSBmcm9tICdAYXVyb3JhL3VpLWtpdCc7XG5pbXBvcnQgeyBBdXRvY29tcGxldGUgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcblxuaW1wb3J0IHsgZm9ybWF0QXV0b2NvbXBsZXRlUGxhY2Vob2xkZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9hdXRvY29tcGxldGUnO1xuaW1wb3J0IHsgQURESVRJT05BTF9ZRUFSUywgRklMVEVSX1NUWUxFLCBTVEFSVF9ZRUFSIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RzJztcblxuY29uc3QgT1BUSU9OUzogc3RyaW5nW10gPSBnZXRZZWFyc0Zyb21TdGFydFllYXIoU1RBUlRfWUVBUiwgQURESVRJT05BTF9ZRUFSUyk7XG5cbmludGVyZmFjZSBJUHJvcHMge1xuICAgIHZhbHVlPzogc3RyaW5nW107XG4gICAgb25DaGFuZ2U6ICh2YWx1ZTogc3RyaW5nW10pID0+IHZvaWQ7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgd2lkdGg6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IEZpbmFuY2lhbFllYXJzRmlsdGVyOiBSZWFjdC5GQzxJUHJvcHM+ID0gKHsgdmFsdWUgPSBbXSwgb25DaGFuZ2UsIGRpc2FibGVkLCB3aWR0aCB9KSA9PiAoXG4gICAgPEF1dG9jb21wbGV0ZVxuICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgIGNzcz17W3sgd2lkdGggfSwgRklMVEVSX1NUWUxFXX1cbiAgICAgICAgbGltaXRUYWdzPXsxfVxuICAgICAgICBpZD1cImZpbmFuY2lhbC15ZWFyc1wiXG4gICAgICAgIG9wdGlvbnM9e09QVElPTlN9XG4gICAgICAgIHNlbGVjdE9uRm9jdXM9e2ZhbHNlfVxuICAgICAgICBnZXRPcHRpb25MYWJlbD17KG9wdGlvbikgPT4gdG9Gb3JtYXRGaW5hbmNpYWxZZWFyKCtvcHRpb24pfVxuICAgICAgICByZW5kZXJPcHRpb249eyhwcm9wcywgb3B0aW9uKSA9PiA8bGkgey4uLnByb3BzfT57dG9Gb3JtYXRGaW5hbmNpYWxZZWFyKCtvcHRpb24pfTwvbGk+fVxuICAgICAgICByZW5kZXJJbnB1dD17KHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8QXVUZXh0RmllbGRcbiAgICAgICAgICAgICAgICAgICAgey4uLnBhcmFtc31cbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2Zvcm1hdEF1dG9jb21wbGV0ZVBsYWNlaG9sZGVyKCfQpNC40L3QsNC90YHQvtCy0YvQuSDQs9C+0LQnLCB2YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICk7XG4gICAgICAgIH19XG4gICAgICAgIGRpc2FibGVDbGVhcmFibGU9e3ZhbHVlICE9PSBudWxsfVxuICAgICAgICBvbkNoYW5nZT17KF8sIHZhbCkgPT4gb25DaGFuZ2UodmFsKX1cbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICBkaXNhYmxlQ2xvc2VPblNlbGVjdFxuICAgICAgICBvcGVuT25Gb2N1c1xuICAgICAgICBtdWx0aXBsZVxuICAgIC8+XG4pO1xuIl19 */"],
  limitTags: 1,
  id: "financial-years",
  options: OPTIONS,
  selectOnFocus: false,
  getOptionLabel: option => (0,_aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_2__.toFormatFinancialYear)(+option),
  renderOption: (props, option) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("li", Object.assign({}, props, {
    children: (0,_aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_2__.toFormatFinancialYear)(+option)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 42
  }, undefined),
  renderInput: params => {
    return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_3__.AuTextField, Object.assign({}, params, {
      readOnly: true,
      placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_4__.formatAutocompletePlaceholder)('Финансовый год', _value),
      size: "small"
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 17
    }, undefined);
  },
  disableClearable: _value !== null,
  onChange: (_, val) => onChange(val),
  disabled: disabled,
  disableCloseOnSelect: true,
  openOnFocus: true,
  multiple: true
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 20,
  columnNumber: 5
}, undefined);
_c2 = FinancialYearsFilter;
var _c, _c2;
__webpack_require__.$Refresh$.register(_c, "OPTIONS");
__webpack_require__.$Refresh$.register(_c2, "FinancialYearsFilter");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 762293:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useFiltersListPage: () => (/* binding */ useFiltersListPage)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(224920);
/* harmony import */ var _routes_hooks_use_query_params__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(876990);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(193461);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _s = __webpack_require__.$Refresh$.signature();





const useFiltersListPage = engagementsData => {
  _s();
  const {
    getQueryParams,
    insertQueryParams
  } = (0,_routes_hooks_use_query_params__WEBPACK_IMPORTED_MODULE_3__.useQueryParams)();
  const queryParams = getQueryParams();
  const currentQueryParams = {
    financialYears: queryParams == null ? void 0 : queryParams.financialYears,
    statuses: queryParams == null ? void 0 : queryParams.statuses,
    clientIds: queryParams == null ? void 0 : queryParams.clientIds,
    isCurrentUserInTeam: queryParams == null ? void 0 : queryParams.isCurrentUserInTeam,
    teamMemberIds: queryParams == null ? void 0 : queryParams.teamMemberIds
  };
  const page = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => {
    var _getQueryParams;
    const currentPage = +(((_getQueryParams = getQueryParams()) == null ? void 0 : _getQueryParams.page) || 0);
    return currentPage < 0 ? 0 : currentPage;
  }, [getQueryParams]);
  const currentFinancialYears = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => {
    var _currentQueryParams$f;
    return currentQueryParams == null || (_currentQueryParams$f = currentQueryParams.financialYears) == null ? void 0 : _currentQueryParams$f.map(i => String(i));
  }, [currentQueryParams == null ? void 0 : currentQueryParams.financialYears]);
  const handlePageChange = (_, newPage) => {
    insertQueryParams({
      limit: _consts__WEBPACK_IMPORTED_MODULE_2__.ROWS_PER_PAGE_50,
      offset: newPage * _consts__WEBPACK_IMPORTED_MODULE_2__.ROWS_PER_PAGE_50,
      page: newPage
    });
  };
  const handleFilterChange = params => {
    insertQueryParams(Object.assign({}, params, {
      offset: 0,
      page: 0
    }));
  };
  const showPagination = (0,_utils__WEBPACK_IMPORTED_MODULE_4__.checkPaginationVisible)(engagementsData);
  return {
    handleFilterChange,
    showPagination,
    handlePageChange,
    currentFinancialYears,
    page,
    currentQueryParams
  };
};
_s(useFiltersListPage, "btIbJj9k99Co5PaJTO0OJFddLvw=", false, function () {
  return [_routes_hooks_use_query_params__WEBPACK_IMPORTED_MODULE_3__.useQueryParams];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 495855:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Filters: () => (/* binding */ Filters)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _aurora_sdk_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(110780);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(224920);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(634984);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(848225);
/* harmony import */ var _client_filter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(885206);
/* harmony import */ var _financial_years_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(849853);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(762293);
/* harmony import */ var _status_filter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(691055);
/* harmony import */ var _team_member_filter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(733507);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/filters/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();













const Filters = /*#__PURE__*/_s( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(_c = _s(function Filters({
  engagementsData,
  isLoading
}) {
  _s();
  const {
    handleFilterChange,
    showPagination,
    handlePageChange,
    currentFinancialYears,
    page,
    currentQueryParams
  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_8__.useFiltersListPage)(engagementsData);
  const isCurrentUserInTeamDefaultValue = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__.useGetCurrentUserInTeamDefaultValue)(currentQueryParams);
  const isCurrentUserInTeam = (0,_aurora_sdk_string__WEBPACK_IMPORTED_MODULE_1__.parseBooleanString)(String(currentQueryParams == null ? void 0 : currentQueryParams.isCurrentUserInTeam)) || (0,_aurora_sdk_string__WEBPACK_IMPORTED_MODULE_1__.parseBooleanString)(String(currentQueryParams == null ? void 0 : currentQueryParams.isCurrentUserInTeam)) === undefined && isCurrentUserInTeamDefaultValue;
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Box, {
    display: "flex",
    justifyContent: "space-between",
    gap: 4,
    children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Stack, {
      gap: 1,
      children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Box, {
        display: "flex",
        gap: 4,
        children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_financial_years_filter__WEBPACK_IMPORTED_MODULE_7__.FinancialYearsFilter, {
          value: currentFinancialYears,
          onChange: val => handleFilterChange({
            financialYears: val.map(Number)
          }),
          disabled: isLoading,
          width: _consts__WEBPACK_IMPORTED_MODULE_4__.FIELD_WIDTH.SMALL
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 21
        }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_status_filter__WEBPACK_IMPORTED_MODULE_9__.StatusFilter, {
          value: currentQueryParams == null ? void 0 : currentQueryParams.statuses,
          onChange: statuses => handleFilterChange({
            statuses
          }),
          disabled: isLoading,
          width: _consts__WEBPACK_IMPORTED_MODULE_4__.FIELD_WIDTH.SMALL
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 21
        }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_client_filter__WEBPACK_IMPORTED_MODULE_6__.ClientFilter, {
          onChange: clientIds => handleFilterChange({
            clientIds
          }),
          disabled: isLoading,
          width: _consts__WEBPACK_IMPORTED_MODULE_4__.FIELD_WIDTH.MEDIUM
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 21
        }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_team_member_filter__WEBPACK_IMPORTED_MODULE_10__.TeamMemberFilter, {
          onChange: teamMemberIds => handleFilterChange({
            teamMemberIds
          }),
          disabled: isLoading,
          width: _consts__WEBPACK_IMPORTED_MODULE_4__.FIELD_WIDTH.MEDIUM
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 55,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 17
      }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Box, {
        children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Chip, {
          label: "\u0422\u043E\u043B\u044C\u043A\u043E \u043C\u043E\u0438",
          size: "medium",
          color: isCurrentUserInTeam ? 'primary' : undefined,
          onClick: () => handleFilterChange({
            isCurrentUserInTeam: isCurrentUserInTeam ? false : true
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 13
    }, this), (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__.TablePagination, {
      visible: showPagination,
      page: page,
      total: (engagementsData == null ? void 0 : engagementsData.pagination.total) || 0,
      rowsPerPage: _consts__WEBPACK_IMPORTED_MODULE_3__.ROWS_PER_PAGE_50,
      onChange: handlePageChange
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 9
  }, this);
}, "+0sKoiDNDSvSobTni/Mu9CA9uKo=", false, function () {
  return [_hooks__WEBPACK_IMPORTED_MODULE_8__.useFiltersListPage, _hooks__WEBPACK_IMPORTED_MODULE_5__.useGetCurrentUserInTeamDefaultValue];
})), "+0sKoiDNDSvSobTni/Mu9CA9uKo=", false, function () {
  return [_hooks__WEBPACK_IMPORTED_MODULE_8__.useFiltersListPage, _hooks__WEBPACK_IMPORTED_MODULE_5__.useGetCurrentUserInTeamDefaultValue];
});
_c2 = Filters;
var _c, _c2;
__webpack_require__.$Refresh$.register(_c, "Filters$React.memo");
__webpack_require__.$Refresh$.register(_c2, "Filters");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 691055:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatusFilter: () => (/* binding */ StatusFilter)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(868845);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(634984);
/* harmony import */ var _status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(388848);
/* harmony import */ var _status_consts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(572542);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/filters/status-filter/index.tsx";









const OPTIONS = ['CREATED'];
const StatusFilter = ({
  value: _value = [],
  onChange,
  disabled,
  width
}) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Autocomplete, {
  value: _value,
  size: "small",
  css: [{
    width
  }, _consts__WEBPACK_IMPORTED_MODULE_4__.FILTER_STYLE,  false ? 0 : ";label:StatusFilter;",  false ? 0 : "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvc3RhdHVzLWZpbHRlci9pbmRleC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBd0JRIiwiZmlsZSI6Ii9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvc3RhdHVzLWZpbHRlci9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBBdVRleHRGaWVsZCB9IGZyb20gJ0BhdXJvcmEvdWkta2l0JztcbmltcG9ydCB7IEF1dG9jb21wbGV0ZSwgQm94LCBDaGlwIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5cbmltcG9ydCB0eXBlIHsgVEVuZ2FnZW1lbnRTdGF0dXMgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9mZWF0dXJlcy9lbmdhZ2VtZW50JztcbmltcG9ydCB7IGZvcm1hdEF1dG9jb21wbGV0ZVBsYWNlaG9sZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vYXV0b2NvbXBsZXRlJztcbmltcG9ydCB7IEZJTFRFUl9TVFlMRSB9IGZyb20gJy4uLy4uLy4uL2NvbnN0cyc7XG5pbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9zdGF0dXMnO1xuaW1wb3J0IHsgU1RBVFVTRVMgfSBmcm9tICcuLi8uLi9zdGF0dXMvY29uc3RzJztcblxuY29uc3QgT1BUSU9OUzogVEVuZ2FnZW1lbnRTdGF0dXNbXSA9IFsnQ1JFQVRFRCddO1xuXG5pbnRlcmZhY2UgSVByb3BzIHtcbiAgICB2YWx1ZT86IFRFbmdhZ2VtZW50U3RhdHVzW107XG4gICAgb25DaGFuZ2U6ICh2YWx1ZTogVEVuZ2FnZW1lbnRTdGF0dXNbXSkgPT4gdm9pZDtcbiAgICBkaXNhYmxlZDogYm9vbGVhbjtcbiAgICB3aWR0aDogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgU3RhdHVzRmlsdGVyOiBSZWFjdC5GQzxJUHJvcHM+ID0gKHsgdmFsdWUgPSBbXSwgb25DaGFuZ2UsIGRpc2FibGVkLCB3aWR0aCB9KSA9PiAoXG4gICAgPEF1dG9jb21wbGV0ZVxuICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgIGNzcz17W3sgd2lkdGggfSwgRklMVEVSX1NUWUxFXX1cbiAgICAgICAgbGltaXRUYWdzPXsxfVxuICAgICAgICBpZD1cInN0YXR1c2VzXCJcbiAgICAgICAgb3B0aW9ucz17T1BUSU9OU31cbiAgICAgICAgc2VsZWN0T25Gb2N1cz17ZmFsc2V9XG4gICAgICAgIGdldE9wdGlvbkxhYmVsPXsob3B0aW9uKSA9PiBTVEFUVVNFU1tvcHRpb25dLmxhYmVsIGFzIHN0cmluZ31cbiAgICAgICAgcmVuZGVyT3B0aW9uPXsocHJvcHMsIG9wdGlvbikgPT4gKFxuICAgICAgICAgICAgPGxpIHsuLi5wcm9wc30+XG4gICAgICAgICAgICAgICAgPFN0YXR1cyBzaXplPVwic21hbGxcIiBzdGF0dXM9e29wdGlvbn0gLz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICl9XG4gICAgICAgIHJlbmRlcklucHV0PXsocGFyYW1zKSA9PiAoXG4gICAgICAgICAgICA8QXVUZXh0RmllbGRcbiAgICAgICAgICAgICAgICB7Li4ucGFyYW1zfVxuICAgICAgICAgICAgICAgIHJlYWRPbmx5XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2Zvcm1hdEF1dG9jb21wbGV0ZVBsYWNlaG9sZGVyKCfQodGC0LDRgtGD0YEnLCB2YWx1ZSl9XG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICAgIGRpc2FibGVDbGVhcmFibGVcbiAgICAgICAgb25DaGFuZ2U9eyhfLCB2YWwpID0+IG9uQ2hhbmdlKHZhbCl9XG4gICAgICAgIHJlbmRlclRhZ3M9eyh2YWwsIGdldFRhZ1Byb3BzKSA9PlxuICAgICAgICAgICAgdmFsLm1hcCgob3B0aW9uLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDxCb3gga2V5PXtpbmRleH0+XG4gICAgICAgICAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD17U1RBVFVTRVNbb3B0aW9uXS52YXJpYW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1NUQVRVU0VTW29wdGlvbl0uY29sb3J9XG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17U1RBVFVTRVNbb3B0aW9uXS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5nZXRUYWdQcm9wcyh7IGluZGV4IH0pfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgKSlcbiAgICAgICAgfVxuICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgIGRpc2FibGVDbG9zZU9uU2VsZWN0XG4gICAgICAgIG9wZW5PbkZvY3VzXG4gICAgICAgIG11bHRpcGxlXG4gICAgLz5cbik7XG4iXX0= */"],
  limitTags: 1,
  id: "statuses",
  options: OPTIONS,
  selectOnFocus: false,
  getOptionLabel: option => _status_consts__WEBPACK_IMPORTED_MODULE_6__.STATUSES[option].label,
  renderOption: (props, option) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("li", Object.assign({}, props, {
    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_status__WEBPACK_IMPORTED_MODULE_5__.Status, {
      size: "small",
      status: option
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 17
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 13
  }, undefined),
  renderInput: params => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__.AuTextField, Object.assign({}, params, {
    readOnly: true,
    placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_3__.formatAutocompletePlaceholder)('Статус', _value),
    size: "small"
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 37,
    columnNumber: 13
  }, undefined),
  disableClearable: true,
  onChange: (_, val) => onChange(val),
  renderTags: (val, getTagProps) => val.map((option, index) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Box, {
    children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Chip, Object.assign({
      size: "small",
      variant: _status_consts__WEBPACK_IMPORTED_MODULE_6__.STATUSES[option].variant,
      color: _status_consts__WEBPACK_IMPORTED_MODULE_6__.STATUSES[option].color,
      label: _status_consts__WEBPACK_IMPORTED_MODULE_6__.STATUSES[option].label
    }, getTagProps({
      index
    })), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 21
    }, undefined)
  }, index, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 17
  }, undefined)),
  disabled: disabled,
  disableCloseOnSelect: true,
  openOnFocus: true,
  multiple: true
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 22,
  columnNumber: 5
}, undefined);
_c = StatusFilter;
var _c;
__webpack_require__.$Refresh$.register(_c, "StatusFilter");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 733507:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TeamMemberFilter: () => (/* binding */ TeamMemberFilter)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(796104);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(130935);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(668291);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _aurora_fe_sdk_hooks_use_on_mount__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(733842);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(790161);
/* harmony import */ var ramda__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(290248);
/* harmony import */ var _features_user__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(705199);
/* harmony import */ var _features_user_models__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(134661);
/* harmony import */ var _routes_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(447177);
/* harmony import */ var _autocomplete__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(868845);
/* harmony import */ var _dictionaries_users__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(97221);
/* harmony import */ var _user_user_card_dense__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(831036);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(634984);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/filters/team-member-filter/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();


















/** TODO: свести компоненты <TeamMemberFilter /> и <UserInput /> */
const TeamMemberFilter = ({
  onChange,
  disabled,
  width
}) => {
  _s();
  var _getQueryParams;
  const {
    getQueryParams
  } = (0,_routes_hooks__WEBPACK_IMPORTED_MODULE_12__.useQueryParams)();
  const [teamMembers, setTeamMembers] = react__WEBPACK_IMPORTED_MODULE_6__.useState([]);
  const [getUsers] = _features_user__WEBPACK_IMPORTED_MODULE_10__.getUsersByParameters.useLazyQuery();
  const teamMemberIds = ((_getQueryParams = getQueryParams()) == null ? void 0 : _getQueryParams.teamMemberIds) || [];
  const handleQueryParamsChange = innerTeamMembers => {
    const ids = innerTeamMembers.map(i => i.id) || [];
    onChange(ids);
  };
  (0,_aurora_fe_sdk_hooks_use_on_mount__WEBPACK_IMPORTED_MODULE_7__.useOnMount)(() => {
    if (teamMemberIds != null && teamMemberIds.length) {
      getUsers({
        ids: teamMemberIds
      }).then(res => {
        var _res$data;
        const newTeamMembers = ((_res$data = res.data) == null || (_res$data = _res$data.data) == null ? void 0 : _res$data.reduce((acc, next) => {
          if (teamMemberIds.includes(next.id)) acc.push(next);
          return acc;
        }, [])) || [];
        setTeamMembers(newTeamMembers);
      });
    }
  });
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_dictionaries_users__WEBPACK_IMPORTED_MODULE_14__.UserInputAutocomplete, {
    id: "team-members",
    limitTags: 3,
    value: teamMembers,
    onChange: (_, value) => {
      handleQueryParamsChange(value);
      setTeamMembers(value);
    },
    minInput: _dictionaries_users__WEBPACK_IMPORTED_MODULE_14__.USER_INPUT_SEARCH_MIN_CHARS,
    size: _consts__WEBPACK_IMPORTED_MODULE_16__.FIELD_SIZE,
    openOnFocus: true,
    renderInput: textFieldParams => {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_8__.AuTextField, Object.assign({}, textFieldParams, {
        placeholder: (0,_autocomplete__WEBPACK_IMPORTED_MODULE_13__.formatAutocompletePlaceholder)(_consts__WEBPACK_IMPORTED_MODULE_16__.FIELD_NAMES.teamMembers, teamMembers),
        size: "small"
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 21
      }, undefined);
    },
    isOptionEqualToValue: ramda__WEBPACK_IMPORTED_MODULE_9__.eqProps('id'),
    getOptionLabel: option => (0,_features_user_models__WEBPACK_IMPORTED_MODULE_11__.getFullName)(option),
    renderOption: (props, option, {
      selected
    }) => {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_user_user_card_dense__WEBPACK_IMPORTED_MODULE_15__.UserCardDense, Object.assign({
        user: option,
        square: true,
        elevation: 0,
        selected: selected,
        component: "li"
      }, props), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 21
      }, undefined);
    },
    ChipProps: {
      sx: {
        width: '120px',
        textOverflow: 'ellipsis'
      }
    },
    css: [{
      width
    }, _consts__WEBPACK_IMPORTED_MODULE_16__.FILTER_STYLE,  false ? 0 : ";label:TeamMemberFilter;",  false ? 0 : "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL2ZpbHRlcnMvdGVhbS1tZW1iZXItZmlsdGVyL2luZGV4LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFxRlkiLCJmaWxlIjoiL1VzZXJzL2tyeWFidWtoaW4wMDEvRG9jdW1lbnRzL2F1cm9yYS9wYWNrYWdlcy9mZS1ob3N0LWFwcC9zcmMvYXBwL2NvbXBvbmVudHMvZW5nYWdlbWVudC9saXN0LXBhZ2UvZmlsdGVycy90ZWFtLW1lbWJlci1maWx0ZXIvaW5kZXgudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyB1c2VPbk1vdW50IH0gZnJvbSAnQGF1cm9yYS9mZS1zZGsvaG9va3MvdXNlLW9uLW1vdW50JztcbmltcG9ydCB7IEF1VGV4dEZpZWxkIH0gZnJvbSAnQGF1cm9yYS91aS1raXQnO1xuaW1wb3J0ICogYXMgUiBmcm9tICdyYW1kYSc7XG5cbmltcG9ydCB7IGdldFVzZXJzQnlQYXJhbWV0ZXJzIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZmVhdHVyZXMvdXNlcic7XG5pbXBvcnQgeyBnZXRGdWxsTmFtZSwgdHlwZSBJVXNlciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2ZlYXR1cmVzL3VzZXIvbW9kZWxzJztcbmltcG9ydCB7IHVzZVF1ZXJ5UGFyYW1zIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vcm91dGVzL2hvb2tzJztcbmltcG9ydCB7IGZvcm1hdEF1dG9jb21wbGV0ZVBsYWNlaG9sZGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vYXV0b2NvbXBsZXRlJztcbmltcG9ydCB7IFVTRVJfSU5QVVRfU0VBUkNIX01JTl9DSEFSUywgVXNlcklucHV0QXV0b2NvbXBsZXRlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZGljdGlvbmFyaWVzL3VzZXJzJztcbmltcG9ydCB7IFVzZXJDYXJkRGVuc2UgfSBmcm9tICcuLi8uLi8uLi8uLi91c2VyL3VzZXItY2FyZC1kZW5zZSc7XG5pbXBvcnQgeyBGSUVMRF9OQU1FUywgRklFTERfU0laRSwgRklMVEVSX1NUWUxFIH0gZnJvbSAnLi4vLi4vLi4vY29uc3RzJztcbmltcG9ydCB0eXBlIHsgVEVuZ2FnZW1lbnRRdWVyeVBhcmFtcyB9IGZyb20gJy4uLy4uLy4uL3R5cGVzJztcblxuaW50ZXJmYWNlIElQcm9wcyB7XG4gICAgb25DaGFuZ2U6ICh2YWx1ZTogc3RyaW5nW10pID0+IHZvaWQ7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgd2lkdGg6IHN0cmluZztcbn1cblxuLyoqIFRPRE86INGB0LLQtdGB0YLQuCDQutC+0LzQv9C+0L3QtdC90YLRiyA8VGVhbU1lbWJlckZpbHRlciAvPiDQuCA8VXNlcklucHV0IC8+ICovXG5leHBvcnQgY29uc3QgVGVhbU1lbWJlckZpbHRlcjogUmVhY3QuRkM8SVByb3BzPiA9ICh7IG9uQ2hhbmdlLCBkaXNhYmxlZCwgd2lkdGggfSkgPT4ge1xuICAgIGNvbnN0IHsgZ2V0UXVlcnlQYXJhbXMgfSA9IHVzZVF1ZXJ5UGFyYW1zKCk7XG4gICAgY29uc3QgW3RlYW1NZW1iZXJzLCBzZXRUZWFtTWVtYmVyc10gPSBSZWFjdC51c2VTdGF0ZTxJVXNlcltdPihbXSk7XG5cbiAgICBjb25zdCBbZ2V0VXNlcnNdID0gZ2V0VXNlcnNCeVBhcmFtZXRlcnMudXNlTGF6eVF1ZXJ5KCk7XG5cbiAgICBjb25zdCB0ZWFtTWVtYmVySWRzID0gZ2V0UXVlcnlQYXJhbXM8VEVuZ2FnZW1lbnRRdWVyeVBhcmFtcz4oKT8udGVhbU1lbWJlcklkcyB8fCBbXTtcblxuICAgIGNvbnN0IGhhbmRsZVF1ZXJ5UGFyYW1zQ2hhbmdlID0gKGlubmVyVGVhbU1lbWJlcnM6IElVc2VyW10pID0+IHtcbiAgICAgICAgY29uc3QgaWRzID0gaW5uZXJUZWFtTWVtYmVycy5tYXAoKGkpID0+IGkuaWQpIHx8IFtdO1xuXG4gICAgICAgIG9uQ2hhbmdlKGlkcyk7XG4gICAgfTtcblxuICAgIHVzZU9uTW91bnQoKCkgPT4ge1xuICAgICAgICBpZiAodGVhbU1lbWJlcklkcz8ubGVuZ3RoKSB7XG4gICAgICAgICAgICBnZXRVc2Vycyh7IGlkczogdGVhbU1lbWJlcklkcyB9KS50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdUZWFtTWVtYmVycyA9XG4gICAgICAgICAgICAgICAgICAgIHJlcy5kYXRhPy5kYXRhPy5yZWR1Y2U8SVVzZXJbXT4oKGFjYywgbmV4dCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRlYW1NZW1iZXJJZHMuaW5jbHVkZXMobmV4dC5pZCkpIGFjYy5wdXNoKG5leHQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgICAgICAgICAgICAgICB9LCBbXSkgfHwgW107XG5cbiAgICAgICAgICAgICAgICBzZXRUZWFtTWVtYmVycyhuZXdUZWFtTWVtYmVycyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPFVzZXJJbnB1dEF1dG9jb21wbGV0ZVxuICAgICAgICAgICAgaWQ9XCJ0ZWFtLW1lbWJlcnNcIlxuICAgICAgICAgICAgbGltaXRUYWdzPXszfVxuICAgICAgICAgICAgdmFsdWU9e3RlYW1NZW1iZXJzfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhfLCB2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGhhbmRsZVF1ZXJ5UGFyYW1zQ2hhbmdlKHZhbHVlKTtcbiAgICAgICAgICAgICAgICBzZXRUZWFtTWVtYmVycyh2YWx1ZSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgbWluSW5wdXQ9e1VTRVJfSU5QVVRfU0VBUkNIX01JTl9DSEFSU31cbiAgICAgICAgICAgIHNpemU9e0ZJRUxEX1NJWkV9XG4gICAgICAgICAgICBvcGVuT25Gb2N1cz17dHJ1ZX1cbiAgICAgICAgICAgIHJlbmRlcklucHV0PXsodGV4dEZpZWxkUGFyYW1zKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPEF1VGV4dEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICB7Li4udGV4dEZpZWxkUGFyYW1zfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2Zvcm1hdEF1dG9jb21wbGV0ZVBsYWNlaG9sZGVyKEZJRUxEX05BTUVTLnRlYW1NZW1iZXJzLCB0ZWFtTWVtYmVycyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgaXNPcHRpb25FcXVhbFRvVmFsdWU9e1IuZXFQcm9wcygnaWQnKX1cbiAgICAgICAgICAgIGdldE9wdGlvbkxhYmVsPXsob3B0aW9uKSA9PiBnZXRGdWxsTmFtZShvcHRpb24pfVxuICAgICAgICAgICAgcmVuZGVyT3B0aW9uPXsocHJvcHMsIG9wdGlvbiwgeyBzZWxlY3RlZCB9KSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPFVzZXJDYXJkRGVuc2UgdXNlcj17b3B0aW9ufSBzcXVhcmUgZWxldmF0aW9uPXswfSBzZWxlY3RlZD17c2VsZWN0ZWR9IGNvbXBvbmVudD1cImxpXCIgey4uLnByb3BzfSAvPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgQ2hpcFByb3BzPXt7XG4gICAgICAgICAgICAgICAgc3g6IHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6ICcxMjBweCcsXG4gICAgICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNzcz17W3sgd2lkdGggfSwgRklMVEVSX1NUWUxFXX1cbiAgICAgICAgICAgIG11bHRpcGxlXG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXX0= */"],
    multiple: true,
    disabled: disabled
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 9
  }, undefined);
};
_s(TeamMemberFilter, "WdEMqoTXg9It6sq8aKRJHzquq2Q=", false, function () {
  return [_routes_hooks__WEBPACK_IMPORTED_MODULE_12__.useQueryParams, _features_user__WEBPACK_IMPORTED_MODULE_10__.getUsersByParameters.useLazyQuery, _aurora_fe_sdk_hooks_use_on_mount__WEBPACK_IMPORTED_MODULE_7__.useOnMount];
});
_c = TeamMemberFilter;
var _c;
__webpack_require__.$Refresh$.register(_c, "TeamMemberFilter");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 848225:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useGetCurrentUserInTeamDefaultValue: () => (/* binding */ useGetCurrentUserInTeamDefaultValue)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(130935);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(668291);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _aurora_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(558447);
/* harmony import */ var _features_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(705199);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _s = __webpack_require__.$Refresh$.signature();




const useGetCurrentUserInTeamDefaultValue = queryParams => {
  _s();
  var _queryParams$isCurren;
  const {
    data: currentUserData
  } = (0,_features_user__WEBPACK_IMPORTED_MODULE_3__.useGetCurrentUserQuery)();
  return (_queryParams$isCurren = queryParams == null ? void 0 : queryParams.isCurrentUserInTeam) != null ? _queryParams$isCurren : currentUserData == null ? void 0 : currentUserData.data.roles.includes(_aurora_common__WEBPACK_IMPORTED_MODULE_2__.EUserRole.USER);
};
_s(useGetCurrentUserInTeamDefaultValue, "dVfdwgzSBfoALnrZxEmeOnm9sv8=", false, function () {
  return [_features_user__WEBPACK_IMPORTED_MODULE_3__.useGetCurrentUserQuery];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 463051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ListPage)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(692221);
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(224920);
/* harmony import */ var _data_models__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(673140);
/* harmony import */ var _features_engagement__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(245303);
/* harmony import */ var _features_user__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(705199);
/* harmony import */ var _routes_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(447177);
/* harmony import */ var _services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3259);
/* harmony import */ var _failed_load_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(485590);
/* harmony import */ var _layouts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(351856);
/* harmony import */ var _layouts_page_title_page_title_skeleton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(978303);
/* harmony import */ var _responses__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(566911);
/* harmony import */ var _templates__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(411120);
/* harmony import */ var _create_engagement__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(35015);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(848225);
/* harmony import */ var _skeleton__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(756019);
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(805502);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();


















const ListPage = () => {
  _s();
  const {
    getQueryParams,
    isQueryParamsApplied
  } = (0,_routes_hooks__WEBPACK_IMPORTED_MODULE_6__.useQueryParams)();
  const queryParams = getQueryParams();
  const isCurrentUserInTeamDefaultValue = (0,_hooks__WEBPACK_IMPORTED_MODULE_14__.useGetCurrentUserInTeamDefaultValue)(queryParams);
  const queryArgs = Object.assign({}, (0,_data_models__WEBPACK_IMPORTED_MODULE_3__.mapSortToDto)(queryParams == null ? void 0 : queryParams.sortField, queryParams == null ? void 0 : queryParams.sortOrder), {
    limit: +((queryParams == null ? void 0 : queryParams.limit) || _consts__WEBPACK_IMPORTED_MODULE_2__.ROWS_PER_PAGE_50),
    offset: +((queryParams == null ? void 0 : queryParams.offset) || 0),
    statuses: queryParams == null ? void 0 : queryParams.statuses,
    financialYears: queryParams == null ? void 0 : queryParams.financialYears,
    clientIds: queryParams == null ? void 0 : queryParams.clientIds,
    // Дефолтное значение true устанавливается здесь
    isCurrentUserInTeam: isCurrentUserInTeamDefaultValue,
    teamMemberIds: queryParams == null ? void 0 : queryParams.teamMemberIds
  });
  const {
    data: engagements,
    isLoading: engagementsLoading,
    isError: engagementsError,
    isFetching: engagementsFetching
  } = (0,_features_engagement__WEBPACK_IMPORTED_MODULE_4__.useGetEngagementsQuery)(queryArgs, {
    refetchOnMountOrArgChange: true
  });
  const {
    isLoading: currentUserLoading,
    isError: currentUserError
  } = (0,_features_user__WEBPACK_IMPORTED_MODULE_5__.useGetCurrentUserQuery)();
  const isLoading = engagementsLoading || currentUserLoading;
  const isError = engagementsError || currentUserError;
  const engagementsData = engagements == null ? void 0 : engagements.data;
  const hasEngagementItems = !!(engagementsData != null && engagementsData.items.length) || isQueryParamsApplied;
  function renderTitle() {
    if (isLoading) {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_layouts_page_title_page_title_skeleton__WEBPACK_IMPORTED_MODULE_10__.PageTitleSkeleton, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 20
      }, this);
    } else {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_layouts__WEBPACK_IMPORTED_MODULE_9__.PageTitle, {
        title: "\u041F\u0440\u043E\u0435\u043A\u0442\u044B",
        children: hasEngagementItems && (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_create_engagement__WEBPACK_IMPORTED_MODULE_13__.CreateEngagement, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 70
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 20
      }, this);
    }
  }
  const renderContent = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => {
    if (isError) {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_failed_load_data__WEBPACK_IMPORTED_MODULE_8__.FailedLoadData, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 20
      }, undefined);
    } else if (isLoading) {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_skeleton__WEBPACK_IMPORTED_MODULE_15__.Skeleton, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 20
      }, undefined);
    } else {
      return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_7__.UserPermissionsGuard, {
        denyComponent: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_responses__WEBPACK_IMPORTED_MODULE_11__.PageForbidden, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 36
        }, undefined),
        isAllowed: builder => builder.Exact('ENGAGEMENT_LIST'),
        children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_table__WEBPACK_IMPORTED_MODULE_16__.Table, {
          engagementsData: engagementsData,
          isLoading: isLoading || engagementsFetching
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 17
      }, undefined);
    }
  }, [engagementsData, engagementsFetching, isLoading, isError]);
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_17__.jsxDEV)(_templates__WEBPACK_IMPORTED_MODULE_12__.PageContentTemplate, {
    scrollableContent: hasEngagementItems,
    showBreadcrumbs: false,
    header: renderTitle(),
    content: renderContent
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 82,
    columnNumber: 9
  }, undefined);
};
_s(ListPage, "2W6NpM7eCdGamVDE3eMj7C9hRbw=", false, function () {
  return [_routes_hooks__WEBPACK_IMPORTED_MODULE_6__.useQueryParams, _hooks__WEBPACK_IMPORTED_MODULE_14__.useGetCurrentUserInTeamDefaultValue, _features_engagement__WEBPACK_IMPORTED_MODULE_4__.useGetEngagementsQuery, _features_user__WEBPACK_IMPORTED_MODULE_5__.useGetCurrentUserQuery];
});
_c = ListPage;

var _c;
__webpack_require__.$Refresh$.register(_c, "ListPage");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 572542:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STATUSES: () => (/* binding */ STATUSES)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

const STATUSES = {
  CREATED: {
    label: 'Создано',
    variant: 'outlined',
    color: 'info'
  }
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 388848:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Status: () => (/* reexport safe */ _status__WEBPACK_IMPORTED_MODULE_0__.Status)
/* harmony export */ });
/* harmony import */ var _status__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(739356);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);



const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 739356:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Status: () => (/* binding */ Status)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(572542);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/status/status.tsx";




const Status = ({
  status,
  size: _size = 'medium'
}) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Chip, {
  size: _size,
  label: _consts__WEBPACK_IMPORTED_MODULE_1__.STATUSES[status].label,
  color: _consts__WEBPACK_IMPORTED_MODULE_1__.STATUSES[status].color,
  variant: _consts__WEBPACK_IMPORTED_MODULE_1__.STATUSES[status].variant
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 15,
  columnNumber: 5
}, undefined);
_c = Status;
var _c;
__webpack_require__.$Refresh$.register(_c, "Status");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 288910:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useEngagementListPage: () => (/* binding */ useEngagementListPage)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(896656);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(345993);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(673444);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(790161);
/* harmony import */ var _mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(254043);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(464901);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _features_engagement__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(245303);
/* harmony import */ var _routes___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(154466);
/* harmony import */ var _routes_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(447177);
/* harmony import */ var _services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3259);
/* harmony import */ var _app_snackbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(949136);
/* harmony import */ var _confirm_modal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(664759);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(634984);
/* harmony import */ var _status__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(388848);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(805502);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/table/hooks.tsx",
  _s = __webpack_require__.$Refresh$.signature();


















const useEngagementListPage = () => {
  _s();
  const {
    showModal,
    hideModal,
    onError
  } = (0,_confirm_modal__WEBPACK_IMPORTED_MODULE_10__.useConfirmModalContext)();
  const {
    removeQueryParams
  } = (0,_routes_hooks__WEBPACK_IMPORTED_MODULE_7__.useQueryParams)();
  const [removeEngagement, {
    isLoading: isRemoveEngagementLoading
  }] = (0,_features_engagement__WEBPACK_IMPORTED_MODULE_5__.useRemoveEngagementMutation)();
  const {
    onSortChange,
    sortingOrder
  } = (0,_routes_hooks__WEBPACK_IMPORTED_MODULE_7__.useSorting)();
  const snackbar = (0,_app_snackbar__WEBPACK_IMPORTED_MODULE_9__.useAppSnackbar)();
  const handleDelete = react__WEBPACK_IMPORTED_MODULE_2___default().useCallback(id => {
    showModal == null || showModal({
      title: _consts__WEBPACK_IMPORTED_MODULE_11__.CONFIRM_MODAL_MESSAGES.DELETE_ENGAGEMENT.TITLE,
      content: _consts__WEBPACK_IMPORTED_MODULE_11__.CONFIRM_MODAL_MESSAGES.DELETE_ENGAGEMENT.CONTENT,
      hideLeftButton: true,
      rightButton: () => removeEngagement({
        engagementId: id
      }).unwrap().then(() => {
        snackbar.add({
          message: _consts__WEBPACK_IMPORTED_MODULE_11__.QUERY_MESSAGES.ENGAGEMENT.REMOVE.SUCCESS,
          key: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_14__.nanoid)(),
          options: {
            variant: 'success'
          }
        });
        hideModal();
      }).catch(e => {
        snackbar.add({
          message: _consts__WEBPACK_IMPORTED_MODULE_11__.QUERY_MESSAGES.ENGAGEMENT.REMOVE.ERROR,
          key: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_14__.nanoid)(),
          options: {
            variant: 'error'
          }
        });
        console.error(e);
        onError();
      })
    });
  }, [showModal, removeEngagement, snackbar, hideModal, onError]);
  const {
    hasPermission: hasUserPermission
  } = (0,_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_8__.useUserPermissions)();
  const hasReadPermission = hasUserPermission(_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_8__.expressionBuilder.Exact('ENGAGEMENT_READ'));
  const hasDeletePermission = hasUserPermission(_services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_8__.expressionBuilder.Exact('ENGAGEMENT_REMOVE'));
  const getItems = react__WEBPACK_IMPORTED_MODULE_2___default().useCallback(id => [(0,_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_4__.getLogMenuItem)((0,_routes___WEBPACK_IMPORTED_MODULE_6__.getEngagementInfoLogsPage)(id)), {
    icon: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_16__["default"], {
      color: "error",
      fontSize: "small"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 23
    }, undefined),
    onClick: () => handleDelete(id),
    label: 'Удалить проект',
    color: 'error',
    hidden: !hasDeletePermission
  }], [handleDelete, hasDeletePermission]);
  const COLUMNS = react__WEBPACK_IMPORTED_MODULE_2___default().useMemo(() => [{
    field: 'name',
    headerName: 'Название',
    flex: 1,
    renderCell: ({
      id,
      value
    }) => {
      const pathname = (0,_routes___WEBPACK_IMPORTED_MODULE_6__.getMainEngagementPage)(String(id));
      if (value) {
        return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_4__.NameLinkCell, {
          noWrap: true,
          withAvatar: true,
          hasReadPermission: hasReadPermission,
          label: value,
          pathname: pathname
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 29
        }, undefined);
      }
      return null;
    }
  }, {
    field: 'client',
    headerName: 'Головной клиент',
    flex: 1,
    renderCell: ({
      value
    }) => {
      var _value$name;
      return (_value$name = value == null ? void 0 : value.name) != null ? _value$name : value == null ? void 0 : value.nameEn;
    }
  }, {
    field: 'financialYear',
    headerName: 'Финансовый год',
    width: 184,
    renderCell: ({
      value
    }) => value ? (0,_aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_3__.toFormatFinancialYear)(value) : null
  }, {
    field: 'status',
    headerName: 'Статус',
    width: 188,
    renderCell: ({
      value
    }) => value ? (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_status__WEBPACK_IMPORTED_MODULE_12__.Status, {
      size: "small",
      status: value
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 124,
      columnNumber: 29
    }, undefined) : null
  }, {
    field: 'actions',
    headerName: '',
    width: 50,
    sortable: false,
    renderCell: ({
      id
    }) => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_17__.Box, {
      css: ___WEBPACK_IMPORTED_MODULE_13__.styles.popup,
      className: "popup",
      children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_4__.MenuItems, {
        items: getItems(String(id)),
        iconSize: "small"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 133,
        columnNumber: 25
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 132,
      columnNumber: 21
    }, undefined)
  }], [hasReadPermission, getItems]);
  return {
    removeQueryParams,
    onSortChange,
    sortingOrder,
    columns: COLUMNS,
    isRemoveEngagementLoading
  };
};
_s(useEngagementListPage, "Rubqt/0lyF+geuOKcZD0D1J/TTo=", false, function () {
  return [_confirm_modal__WEBPACK_IMPORTED_MODULE_10__.useConfirmModalContext, _routes_hooks__WEBPACK_IMPORTED_MODULE_7__.useQueryParams, _features_engagement__WEBPACK_IMPORTED_MODULE_5__.useRemoveEngagementMutation, _routes_hooks__WEBPACK_IMPORTED_MODULE_7__.useSorting, _app_snackbar__WEBPACK_IMPORTED_MODULE_9__.useAppSnackbar, _services_permissions_user_permissions__WEBPACK_IMPORTED_MODULE_8__.useUserPermissions];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 805502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Table: () => (/* binding */ Table),
/* harmony export */   styles: () => (/* binding */ styles)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(514041);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(659980);
/* harmony import */ var _aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(790161);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(651406);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(940422);
/* harmony import */ var _create_engagement__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35015);
/* harmony import */ var _filters__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(495855);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(288910);
/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(325712);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

var _jsxFileName = "/Users/kryabukhin001/Documents/aurora/packages/fe-host-app/src/app/components/engagement/list-page/table/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }










var _ref =  false ? 0 : {
  name: "zoih4e-table",
  styles: ".MuiDataGrid-row:hover{.popup{display:inline-block!important;}};label:table;",
  map: "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL3RhYmxlL2luZGV4LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFlb0IiLCJmaWxlIjoiL1VzZXJzL2tyeWFidWtoaW4wMDEvRG9jdW1lbnRzL2F1cm9yYS9wYWNrYWdlcy9mZS1ob3N0LWFwcC9zcmMvYXBwL2NvbXBvbmVudHMvZW5nYWdlbWVudC9saXN0LXBhZ2UvdGFibGUvaW5kZXgudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgZW1wdHkgfSBmcm9tICdAYXVyb3JhL3Nkay9kYXRhL2FycmF5JztcbmltcG9ydCB7IERhdGFUYWJsZSwgRW1wdHlEYXRhLCBFbXB0eUZpbHRlciB9IGZyb20gJ0BhdXJvcmEvdWkta2l0JztcbmltcG9ydCB7IGNzcyB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IEJveCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuXG5pbXBvcnQgdHlwZSB7IFRFbmdhZ2VtZW50c0RhdGEgfSBmcm9tICcuLi8uLi8uLi8uLi9mZWF0dXJlcy9lbmdhZ2VtZW50JztcbmltcG9ydCB7IEVtcHR5TGlzdElsbHVzdHJhdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2ljb25zJztcbmltcG9ydCB7IENyZWF0ZUVuZ2FnZW1lbnQgfSBmcm9tICcuLi8uLi9jcmVhdGUtZW5nYWdlbWVudCc7XG5pbXBvcnQgeyBGaWx0ZXJzIH0gZnJvbSAnLi4vZmlsdGVycyc7XG5cbmltcG9ydCB7IHVzZUVuZ2FnZW1lbnRMaXN0UGFnZSB9IGZyb20gJy4vaG9va3MnO1xuXG5leHBvcnQgY29uc3Qgc3R5bGVzID0ge1xuICAgIHRhYmxlOiAoKSA9PiBjc3NgXG4gICAgICAgIC5NdWlEYXRhR3JpZC1yb3c6aG92ZXIge1xuICAgICAgICAgICAgLnBvcHVwIHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIGAsXG4gICAgcG9wdXA6IGNzc2BcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICBgLFxufTtcblxuaW50ZXJmYWNlIElQcm9wcyB7XG4gICAgZW5nYWdlbWVudHNEYXRhPzogVEVuZ2FnZW1lbnRzRGF0YTtcbiAgICBpc0xvYWRpbmc6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBUYWJsZTogUmVhY3QuRkM8SVByb3BzPiA9ICh7IGVuZ2FnZW1lbnRzRGF0YSwgaXNMb2FkaW5nIH0pID0+IHtcbiAgICBjb25zdCB7IHJlbW92ZVF1ZXJ5UGFyYW1zLCBvblNvcnRDaGFuZ2UsIHNvcnRpbmdPcmRlciwgaXNSZW1vdmVFbmdhZ2VtZW50TG9hZGluZywgY29sdW1ucyB9ID1cbiAgICAgICAgdXNlRW5nYWdlbWVudExpc3RQYWdlKCk7XG5cbiAgICBjb25zdCBpc0ZldGNoaW5nID0gaXNMb2FkaW5nIHx8IGlzUmVtb3ZlRW5nYWdlbWVudExvYWRpbmc7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8Qm94IGRpc3BsYXk9XCJncmlkXCIgZ3JpZFRlbXBsYXRlUm93cz1cImF1dG8gMWZyXCIgaGVpZ2h0PVwiaW5oZXJpdFwiPlxuICAgICAgICAgICAgPEZpbHRlcnMgaXNMb2FkaW5nPXtpc0ZldGNoaW5nfSBlbmdhZ2VtZW50c0RhdGE9e2VuZ2FnZW1lbnRzRGF0YX0gLz5cbiAgICAgICAgICAgIHtCb29sZWFuKGVuZ2FnZW1lbnRzRGF0YT8uaXRlbXMubGVuZ3RoKSA/IChcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzZXM9e3sgcm9vdDogc3R5bGVzLnRhYmxlIH19XG4gICAgICAgICAgICAgICAgICAgIHJvd3M9e2VuZ2FnZW1lbnRzRGF0YT8uaXRlbXMgPz8gZW1wdHl9XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XG4gICAgICAgICAgICAgICAgICAgIGhpZGVGb290ZXJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZUNvbHVtbk1lbnVcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZVJvd1NlbGVjdGlvbk9uQ2xpY2tcbiAgICAgICAgICAgICAgICAgICAgc29ydGluZ01vZGU9XCJzZXJ2ZXJcIlxuICAgICAgICAgICAgICAgICAgICBzb3J0aW5nT3JkZXI9e3NvcnRpbmdPcmRlcn1cbiAgICAgICAgICAgICAgICAgICAgb25Tb3J0TW9kZWxDaGFuZ2U9e29uU29ydENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNGZXRjaGluZ31cbiAgICAgICAgICAgICAgICAgICAgc2xvdHM9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vUm93c092ZXJsYXk6ICgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGhlaWdodD1cIjEwMCVcIiBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHlGaWx0ZXIgdGl0bGU9XCLQn9C+0LTRhdC+0LTRj9GJ0LjRhSDQv9GA0L7QtdC60YLQvtCyINC90LUg0L3QsNC50LTQtdC90L5cIiBvbkNsaWNrPXtyZW1vdmVRdWVyeVBhcmFtc30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPEVtcHR5RGF0YVxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8RW1wdHlMaXN0SWxsdXN0cmF0aW9uIC8+fVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cItCh0L/QuNGB0L7QuiDQv9GA0L7QtdC60YLQvtCyINC/0YPRgdGCXCJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXs8Q3JlYXRlRW5nYWdlbWVudCAvPn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9Cb3g+XG4gICAgKTtcbn07XG4iXX0= */",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
const styles = {
  table: () => _ref,
  popup:  false ? 0 : {
    name: "bw7n71-popup",
    styles: "display:none;label:popup;",
    map: "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9rcnlhYnVraGluMDAxL0RvY3VtZW50cy9hdXJvcmEvcGFja2FnZXMvZmUtaG9zdC1hcHAvc3JjL2FwcC9jb21wb25lbnRzL2VuZ2FnZW1lbnQvbGlzdC1wYWdlL3RhYmxlL2luZGV4LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFzQmMiLCJmaWxlIjoiL1VzZXJzL2tyeWFidWtoaW4wMDEvRG9jdW1lbnRzL2F1cm9yYS9wYWNrYWdlcy9mZS1ob3N0LWFwcC9zcmMvYXBwL2NvbXBvbmVudHMvZW5nYWdlbWVudC9saXN0LXBhZ2UvdGFibGUvaW5kZXgudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgZW1wdHkgfSBmcm9tICdAYXVyb3JhL3Nkay9kYXRhL2FycmF5JztcbmltcG9ydCB7IERhdGFUYWJsZSwgRW1wdHlEYXRhLCBFbXB0eUZpbHRlciB9IGZyb20gJ0BhdXJvcmEvdWkta2l0JztcbmltcG9ydCB7IGNzcyB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IEJveCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuXG5pbXBvcnQgdHlwZSB7IFRFbmdhZ2VtZW50c0RhdGEgfSBmcm9tICcuLi8uLi8uLi8uLi9mZWF0dXJlcy9lbmdhZ2VtZW50JztcbmltcG9ydCB7IEVtcHR5TGlzdElsbHVzdHJhdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL2ljb25zJztcbmltcG9ydCB7IENyZWF0ZUVuZ2FnZW1lbnQgfSBmcm9tICcuLi8uLi9jcmVhdGUtZW5nYWdlbWVudCc7XG5pbXBvcnQgeyBGaWx0ZXJzIH0gZnJvbSAnLi4vZmlsdGVycyc7XG5cbmltcG9ydCB7IHVzZUVuZ2FnZW1lbnRMaXN0UGFnZSB9IGZyb20gJy4vaG9va3MnO1xuXG5leHBvcnQgY29uc3Qgc3R5bGVzID0ge1xuICAgIHRhYmxlOiAoKSA9PiBjc3NgXG4gICAgICAgIC5NdWlEYXRhR3JpZC1yb3c6aG92ZXIge1xuICAgICAgICAgICAgLnBvcHVwIHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIGAsXG4gICAgcG9wdXA6IGNzc2BcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICBgLFxufTtcblxuaW50ZXJmYWNlIElQcm9wcyB7XG4gICAgZW5nYWdlbWVudHNEYXRhPzogVEVuZ2FnZW1lbnRzRGF0YTtcbiAgICBpc0xvYWRpbmc6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBUYWJsZTogUmVhY3QuRkM8SVByb3BzPiA9ICh7IGVuZ2FnZW1lbnRzRGF0YSwgaXNMb2FkaW5nIH0pID0+IHtcbiAgICBjb25zdCB7IHJlbW92ZVF1ZXJ5UGFyYW1zLCBvblNvcnRDaGFuZ2UsIHNvcnRpbmdPcmRlciwgaXNSZW1vdmVFbmdhZ2VtZW50TG9hZGluZywgY29sdW1ucyB9ID1cbiAgICAgICAgdXNlRW5nYWdlbWVudExpc3RQYWdlKCk7XG5cbiAgICBjb25zdCBpc0ZldGNoaW5nID0gaXNMb2FkaW5nIHx8IGlzUmVtb3ZlRW5nYWdlbWVudExvYWRpbmc7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8Qm94IGRpc3BsYXk9XCJncmlkXCIgZ3JpZFRlbXBsYXRlUm93cz1cImF1dG8gMWZyXCIgaGVpZ2h0PVwiaW5oZXJpdFwiPlxuICAgICAgICAgICAgPEZpbHRlcnMgaXNMb2FkaW5nPXtpc0ZldGNoaW5nfSBlbmdhZ2VtZW50c0RhdGE9e2VuZ2FnZW1lbnRzRGF0YX0gLz5cbiAgICAgICAgICAgIHtCb29sZWFuKGVuZ2FnZW1lbnRzRGF0YT8uaXRlbXMubGVuZ3RoKSA/IChcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzZXM9e3sgcm9vdDogc3R5bGVzLnRhYmxlIH19XG4gICAgICAgICAgICAgICAgICAgIHJvd3M9e2VuZ2FnZW1lbnRzRGF0YT8uaXRlbXMgPz8gZW1wdHl9XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XG4gICAgICAgICAgICAgICAgICAgIGhpZGVGb290ZXJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZUNvbHVtbk1lbnVcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZVJvd1NlbGVjdGlvbk9uQ2xpY2tcbiAgICAgICAgICAgICAgICAgICAgc29ydGluZ01vZGU9XCJzZXJ2ZXJcIlxuICAgICAgICAgICAgICAgICAgICBzb3J0aW5nT3JkZXI9e3NvcnRpbmdPcmRlcn1cbiAgICAgICAgICAgICAgICAgICAgb25Tb3J0TW9kZWxDaGFuZ2U9e29uU29ydENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNGZXRjaGluZ31cbiAgICAgICAgICAgICAgICAgICAgc2xvdHM9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vUm93c092ZXJsYXk6ICgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGhlaWdodD1cIjEwMCVcIiBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHlGaWx0ZXIgdGl0bGU9XCLQn9C+0LTRhdC+0LTRj9GJ0LjRhSDQv9GA0L7QtdC60YLQvtCyINC90LUg0L3QsNC50LTQtdC90L5cIiBvbkNsaWNrPXtyZW1vdmVRdWVyeVBhcmFtc30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPEVtcHR5RGF0YVxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8RW1wdHlMaXN0SWxsdXN0cmF0aW9uIC8+fVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cItCh0L/QuNGB0L7QuiDQv9GA0L7QtdC60YLQvtCyINC/0YPRgdGCXCJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXs8Q3JlYXRlRW5nYWdlbWVudCAvPn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9Cb3g+XG4gICAgKTtcbn07XG4iXX0= */",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};
const Table = ({
  engagementsData,
  isLoading
}) => {
  _s();
  var _engagementsData$item;
  const {
    removeQueryParams,
    onSortChange,
    sortingOrder,
    isRemoveEngagementLoading,
    columns
  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__.useEngagementListPage)();
  const isFetching = isLoading || isRemoveEngagementLoading;
  return (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Box, {
    display: "grid",
    gridTemplateRows: "auto 1fr",
    height: "inherit",
    children: [(0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_filters__WEBPACK_IMPORTED_MODULE_5__.Filters, {
      isLoading: isFetching,
      engagementsData: engagementsData
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }, undefined), Boolean(engagementsData == null ? void 0 : engagementsData.items.length) ? (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__.DataTable, {
      classes: {
        root: styles.table
      },
      rows: (_engagementsData$item = engagementsData == null ? void 0 : engagementsData.items) != null ? _engagementsData$item : _aurora_sdk_data_array__WEBPACK_IMPORTED_MODULE_1__.empty,
      columns: columns,
      hideFooter: true,
      disableColumnMenu: true,
      disableRowSelectionOnClick: true,
      sortingMode: "server",
      sortingOrder: sortingOrder,
      onSortModelChange: onSortChange,
      loading: isFetching,
      slots: {
        noRowsOverlay: () => (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Box, {
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          children: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__.EmptyFilter, {
            title: "\u041F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E",
            onClick: removeQueryParams
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 33
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 29
        }, undefined)
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 17
    }, undefined) : (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_aurora_ui_kit__WEBPACK_IMPORTED_MODULE_2__.EmptyData, {
      icon: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_icons__WEBPACK_IMPORTED_MODULE_3__.EmptyListIllustration, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 27
      }, undefined),
      title: "\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432 \u043F\u0443\u0441\u0442",
      action: (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_create_engagement__WEBPACK_IMPORTED_MODULE_4__.CreateEngagement, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 29
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 17
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 40,
    columnNumber: 9
  }, undefined);
};
_s(Table, "BRJgUTCoWNwL2t8WtHhFt02cnuo=", false, function () {
  return [_hooks__WEBPACK_IMPORTED_MODULE_6__.useEngagementListPage];
});
_c = Table;
var _c;
__webpack_require__.$Refresh$.register(_c, "Table");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 272713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getClientNameView: () => (/* binding */ getClientNameView)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);

/**
 * Функция отображение имени клиента (клиент аудита)
 */
function getClientNameView(client) {
  var _client$name;
  return `${(_client$name = client.name) != null ? _client$name : client.nameEn}`;
}

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ 193461:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   calculateMaxLengthIncludeFormatting: () => (/* binding */ calculateMaxLengthIncludeFormatting),
/* harmony export */   checkPaginationVisible: () => (/* binding */ checkPaginationVisible),
/* harmony export */   convertEmptyStringToNull: () => (/* binding */ convertEmptyStringToNull),
/* harmony export */   validateValueForMoneyFields: () => (/* binding */ validateValueForMoneyFields)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(130935);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(668291);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93831);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(830488);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(673444);
/* harmony import */ var _consts_regex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(208803);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(797187);
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(675583);
__webpack_require__.$Refresh$.runtime = __webpack_require__(506267);








/**
 *
 * @param data
 * @param silentMode Режим при котором не проверяется наличие элементов сущности
 * @returns boolean
 */
const checkPaginationVisible = (data, silentMode) => {
  return silentMode ? !!(data && data.pagination.total > data.pagination.limit) : !!(data && data.pagination.total > data.pagination.limit && data.items.length);
};
const convertEmptyStringToNull = value => {
  return value || null;
};

/** Расчет максимальной длины строки с учетом пробелов */
const calculateMaxLengthIncludeFormatting = (maxLength, value) => {
  if (!value) return maxLength;

  // приводит число к строке с пробелами в качестве разделителей: 1 000 000
  const localString = _aurora_fe_sdk_numbers__WEBPACK_IMPORTED_MODULE_4__.localeFloatFormatter.format(value);
  let additionalLimit = 0;

  // в каждой группе разрядности по 3 символа. При наличии 3 или менее символов разделитель не добавляется
  if (localString.length <= 3) return maxLength;
  if (localString.includes('-')) {
    additionalLimit++;
  }
  additionalLimit += localString.split(/\s/d).length - 1;
  return maxLength + additionalLimit;
};

/**
 * Функция проверяет, является ли данное значение либо пустой строкой,
 * либо соответствует шаблону, определенному INTEGER_VALIDATION_REGEX.
 */
const validateValueForMoneyFields = value => {
  return value === null || _consts_regex__WEBPACK_IMPORTED_MODULE_5__.INTEGER_VALIDATION_REGEX.test(value);
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

}]);